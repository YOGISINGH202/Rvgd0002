import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/language_selection_widget.dart';
import './widgets/onboarding_page_widget.dart';
import './widgets/page_indicator_widget.dart';
import './widgets/permission_request_widget.dart';
import './widgets/qr_demo_widget.dart';
import './widgets/voice_demo_widget.dart';

class OnboardingFlow extends StatefulWidget {
  const OnboardingFlow({super.key});

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _OnboardingFlowState extends State<OnboardingFlow> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  String _selectedLanguage = 'English';

  final List<Map<String, dynamic>> _onboardingData = [
    {
      'title': 'Voice-First Cultural Exploration',
      'description':
          'Experience Rajasthan\'s rich heritage through AI-powered voice guides that bring monuments to life with stories, history, and cultural insights.',
      'imagePath':
          'https://images.unsplash.com/photo-1587474260584-136574528ed5?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3',
      'hasInteraction': true,
      'interactionType': 'voice',
    },
    {
      'title': 'Instant Monument Recognition',
      'description':
          'Simply scan QR codes at heritage sites to unlock detailed information, audio guides, and interactive experiences tailored to your interests.',
      'imagePath':
          'https://images.unsplash.com/photo-1564507592333-c60657eea523?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3',
      'hasInteraction': true,
      'interactionType': 'qr',
    },
    {
      'title': 'AI-Powered Cultural Q&A',
      'description':
          'Ask questions about traditions, rituals, architecture, or local customs and get instant answers from our intelligent cultural assistant.',
      'imagePath':
          'https://images.unsplash.com/photo-1609137144813-7d9921338f24?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3',
      'hasInteraction': false,
      'interactionType': null,
    },
    {
      'title': 'Personalized Cultural Journey',
      'description':
          'Choose your language and interests to create a customized exploration experience that matches your cultural curiosity and travel style.',
      'imagePath':
          'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3',
      'hasInteraction': true,
      'interactionType': 'language',
      'isLastPage': true,
    },
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _nextPage() {
    if (_currentPage < _onboardingData.length - 1) {
      HapticFeedback.lightImpact();
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _completeOnboarding();
    }
  }

  void _previousPage() {
    if (_currentPage > 0) {
      HapticFeedback.lightImpact();
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _skipOnboarding() {
    HapticFeedback.lightImpact();
    _completeOnboarding();
  }

  void _completeOnboarding() {
    Navigator.pushReplacementNamed(context, '/home-screen');
  }

  void _onLanguageSelected(String language) {
    setState(() {
      _selectedLanguage = language;
    });
  }

  void _onPermissionsGranted() {
    _completeOnboarding();
  }

  Widget _buildInteractiveWidget(String interactionType) {
    switch (interactionType) {
      case 'voice':
        return const VoiceDemoWidget();
      case 'qr':
        return const QrDemoWidget();
      case 'language':
        return LanguageSelectionWidget(
          onLanguageSelected: _onLanguageSelected,
        );
      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: Stack(
        children: [
          // Main content
          PageView.builder(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                _currentPage = index;
              });
              HapticFeedback.selectionClick();
            },
            itemCount: _onboardingData.length,
            itemBuilder: (context, index) {
              final data = _onboardingData[index];
              return OnboardingPageWidget(
                title: data['title'],
                description: data['description'],
                imagePath: data['imagePath'],
                interactiveWidget: data['hasInteraction']
                    ? _buildInteractiveWidget(data['interactionType'])
                    : null,
                isLastPage: data['isLastPage'] ?? false,
              );
            },
          ),

          // Skip button
          if (_currentPage < _onboardingData.length - 1)
            Positioned(
              top: 8.h,
              right: 6.w,
              child: SafeArea(
                child: TextButton(
                  onPressed: _skipOnboarding,
                  style: TextButton.styleFrom(
                    backgroundColor: colorScheme.surface.withValues(alpha: 0.9),
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: Text(
                    'Skip',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: colorScheme.onSurface.withValues(alpha: 0.8),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ),

          // Bottom navigation area
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(6.w),
              decoration: BoxDecoration(
                color: colorScheme.surface,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: colorScheme.shadow.withValues(alpha: 0.1),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: SafeArea(
                child: _currentPage == _onboardingData.length - 1
                    ? PermissionRequestWidget(
                        onPermissionsGranted: _onPermissionsGranted,
                      )
                    : Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Page indicator
                          PageIndicatorWidget(
                            currentPage: _currentPage,
                            totalPages: _onboardingData.length,
                          ),

                          SizedBox(height: 3.h),

                          // Navigation buttons
                          Row(
                            children: [
                              // Previous button
                              if (_currentPage > 0)
                                Expanded(
                                  child: OutlinedButton(
                                    onPressed: _previousPage,
                                    style: OutlinedButton.styleFrom(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 2.h),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        CustomIconWidget(
                                          iconName: 'arrow_back',
                                          color: colorScheme.primary,
                                          size: 20,
                                        ),
                                        SizedBox(width: 2.w),
                                        Text('Previous'),
                                      ],
                                    ),
                                  ),
                                )
                              else
                                const Spacer(),

                              if (_currentPage > 0) SizedBox(width: 4.w),

                              // Next button
                              Expanded(
                                flex: _currentPage > 0 ? 1 : 2,
                                child: ElevatedButton(
                                  onPressed: _nextPage,
                                  style: ElevatedButton.styleFrom(
                                    padding:
                                        EdgeInsets.symmetric(vertical: 2.h),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        _currentPage ==
                                                _onboardingData.length - 2
                                            ? 'Get Started'
                                            : 'Next',
                                      ),
                                      SizedBox(width: 2.w),
                                      CustomIconWidget(
                                        iconName: _currentPage ==
                                                _onboardingData.length - 2
                                            ? 'rocket_launch'
                                            : 'arrow_forward',
                                        color: colorScheme.onPrimary,
                                        size: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
