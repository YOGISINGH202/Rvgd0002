import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/recent_scans_widget.dart';
import './widgets/scan_result_widget.dart';
import './widgets/scanning_overlay_widget.dart';
import './widgets/torch_control_widget.dart';

class QrCodeScanner extends StatefulWidget {
  const QrCodeScanner({super.key});

  @override
  State<QrCodeScanner> createState() => _QrCodeScannerState();
}

class _QrCodeScannerState extends State<QrCodeScanner>
    with WidgetsBindingObserver {
  MobileScannerController? _scannerController;
  bool _isScanning = false;
  bool _isTorchOn = false;
  bool _showTorchControl = false;
  bool _hasPermission = false;
  Map<String, dynamic>? _scanResult;
  String _instructionText = 'Point camera at monument QR code';

  // Mock data for recent scans
  final List<Map<String, dynamic>> _recentScans = [
    {
      'id': 'hawa_mahal_001',
      'name': 'Hawa Mahal',
      'location': 'Jaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1599661046289-e31897846e41?w=400&h=300&fit=crop',
      'period': '18th Century',
      'timeAgo': '2 hours ago',
      'qrData': 'hawa_mahal_heritage_site',
    },
    {
      'id': 'amber_fort_001',
      'name': 'Amber Fort',
      'location': 'Amer, Jaipur',
      'image':
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
      'period': '16th Century',
      'timeAgo': '1 day ago',
      'qrData': 'amber_fort_heritage_site',
    },
    {
      'id': 'city_palace_001',
      'name': 'City Palace',
      'location': 'Jaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=400&h=300&fit=crop',
      'period': '18th Century',
      'timeAgo': '3 days ago',
      'qrData': 'city_palace_heritage_site',
    },
  ];

  // Mock monument database for QR code recognition
  final Map<String, Map<String, dynamic>> _monumentDatabase = {
    'hawa_mahal_heritage_site': {
      'id': 'hawa_mahal_001',
      'name': 'Hawa Mahal (Palace of Winds)',
      'location': 'Badi Choupad, Jaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1599661046289-e31897846e41?w=400&h=300&fit=crop',
      'period': '18th Century (1799)',
      'description':
          'A stunning five-story palace built by Maharaja Sawai Pratap Singh, featuring 953 small windows called jharokhas.',
      'architect': 'Lal Chand Ustad',
      'significance': 'UNESCO World Heritage Site candidate',
    },
    'amber_fort_heritage_site': {
      'id': 'amber_fort_001',
      'name': 'Amber Fort (Amer Fort)',
      'location': 'Amer, Jaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
      'period': '16th Century (1592)',
      'description':
          'A majestic fort palace built by Raja Man Singh I, known for its artistic Hindu style elements.',
      'architect': 'Raja Man Singh I',
      'significance': 'UNESCO World Heritage Site',
    },
    'city_palace_heritage_site': {
      'id': 'city_palace_001',
      'name': 'City Palace Jaipur',
      'location': 'Tulsi Marg, Jaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=400&h=300&fit=crop',
      'period': '18th Century (1729)',
      'description':
          'A royal residence complex built by Maharaja Sawai Jai Singh II, showcasing Rajput and Mughal architecture.',
      'architect': 'Maharaja Sawai Jai Singh II',
      'significance': 'Active royal residence and museum',
    },
    'jantar_mantar_heritage_site': {
      'id': 'jantar_mantar_001',
      'name': 'Jantar Mantar',
      'location': 'Gangori Bazaar, Jaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1582650625119-3a31f8fa2699?w=400&h=300&fit=crop',
      'period': '18th Century (1734)',
      'description':
          'An astronomical observation site built by Maharaja Sawai Jai Singh II, featuring the world\'s largest stone sundial.',
      'architect': 'Maharaja Sawai Jai Singh II',
      'significance': 'UNESCO World Heritage Site',
    },
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _requestCameraPermission();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scannerController?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_scannerController == null ||
        !_scannerController!.value.isInitialized) {
      return;
    }

    switch (state) {
      case AppLifecycleState.detached:
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
        _scannerController?.stop();
        break;
      case AppLifecycleState.resumed:
        _scannerController?.start();
        break;
      case AppLifecycleState.inactive:
        break;
    }
  }

  Future<void> _requestCameraPermission() async {
    final status = await Permission.camera.request();
    setState(() {
      _hasPermission = status.isGranted;
    });

    if (_hasPermission) {
      await _initializeScanner();
    }
  }

  Future<void> _initializeScanner() async {
    try {
      _scannerController = MobileScannerController(
        detectionSpeed: DetectionSpeed.noDuplicates,
        facing: CameraFacing.back,
        torchEnabled: false,
      );

      await _scannerController!.start();

      setState(() {
        _isScanning = true;
      });

      // Listen for torch availability - remove torchState listener as it doesn't exist
      // The controller's value property contains torchState updates
    } catch (e) {
      debugPrint('Error initializing scanner: $e');
      setState(() {
        _instructionText = 'Camera initialization failed. Please try again.';
      });
    }
  }

  void _onDetect(BarcodeCapture capture) {
    final List<Barcode> barcodes = capture.barcodes;

    if (barcodes.isNotEmpty && _scanResult == null) {
      final barcode = barcodes.first;
      final qrData = barcode.rawValue;

      if (qrData != null) {
        // Provide haptic feedback
        HapticFeedback.mediumImpact();

        // Check if QR code matches a monument in our database
        final monumentData = _monumentDatabase[qrData];

        if (monumentData != null) {
          setState(() {
            _scanResult = monumentData;
            _isScanning = false;
          });

          // Add to recent scans if not already present
          final existingIndex = _recentScans.indexWhere(
            (scan) => scan['qrData'] == qrData,
          );

          if (existingIndex == -1) {
            _recentScans.insert(0, {
              ...monumentData,
              'qrData': qrData,
              'timeAgo': 'Just now',
            });

            // Keep only last 10 scans
            if (_recentScans.length > 10) {
              _recentScans.removeRange(10, _recentScans.length);
            }
          } else {
            // Move to front and update time
            final scan = _recentScans.removeAt(existingIndex);
            scan['timeAgo'] = 'Just now';
            _recentScans.insert(0, scan);
          }
        } else {
          // Invalid QR code - show error with shake animation
          _showInvalidQRError();
        }
      }
    }
  }

  void _showInvalidQRError() {
    HapticFeedback.lightImpact();
    setState(() {
      _instructionText = 'Invalid QR code. Please scan a monument QR code.';
    });

    // Reset instruction text after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _instructionText = 'Point camera at monument QR code';
        });
      }
    });
  }

  void _toggleTorch() async {
    if (_scannerController != null) {
      try {
        await _scannerController!.toggleTorch();
        setState(() {
          _isTorchOn = !_isTorchOn;
        });
      } catch (e) {
        debugPrint('Error toggling torch: $e');
      }
    }
  }

  void _resetScanner() {
    setState(() {
      _scanResult = null;
      _isScanning = true;
      _instructionText = 'Point camera at monument QR code';
    });
  }

  void _navigateToMonumentDetail(Map<String, dynamic> monument) {
    Navigator.pushNamed(
      context,
      '/monument-detail-screen',
      arguments: monument,
    );
  }

  void _startVoiceGuide(Map<String, dynamic> monument) {
    Navigator.pushNamed(
      context,
      '/voice-guide-player',
      arguments: monument,
    );
  }

  void _onRecentScanTap(Map<String, dynamic> scan) {
    setState(() {
      _scanResult = scan;
      _isScanning = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Camera preview
          if (_hasPermission && _scannerController != null)
            MobileScanner(
              controller: _scannerController!,
              onDetect: _onDetect,
            )
          else
            _buildPermissionDeniedView(),

          // Scanning overlay
          if (_hasPermission)
            ScanningOverlayWidget(
              isScanning: _isScanning,
              instructionText: _instructionText,
              onClose: () => Navigator.of(context).pop(),
            ),

          // Torch control
          if (_showTorchControl && _hasPermission)
            Positioned(
              top: 25.h,
              right: 4.w,
              child: SafeArea(
                child: TorchControlWidget(
                  isTorchOn: _isTorchOn,
                  isVisible: _showTorchControl,
                  onToggle: _toggleTorch,
                ),
              ),
            ),

          // Recent scans bottom sheet
          if (_hasPermission)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: RecentScansWidget(
                recentScans: _recentScans,
                onScanTap: _onRecentScanTap,
              ),
            ),

          // Scan result overlay
          if (_scanResult != null)
            Positioned(
              bottom: 35.h,
              left: 0,
              right: 0,
              child: ScanResultWidget(
                scanResult: _scanResult,
                onViewDetails: () => _navigateToMonumentDetail(_scanResult!),
                onStartVoiceGuide: () => _startVoiceGuide(_scanResult!),
                onClose: _resetScanner,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPermissionDeniedView() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Colors.black,
      child: SafeArea(
        child: Column(
          children: [
            // Close button
            Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: EdgeInsets.all(4.w),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: CustomIconWidget(
                      iconName: 'close',
                      color: Colors.white,
                      size: 6.w,
                    ),
                  ),
                ),
              ),
            ),

            // Permission denied content
            Expanded(
              child: Center(
                child: Padding(
                  padding: EdgeInsets.all(6.w),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.all(6.w),
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.colorScheme.primary
                              .withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: CustomIconWidget(
                          iconName: 'camera_alt',
                          color: AppTheme.lightTheme.colorScheme.primary,
                          size: 15.w,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        'Camera Permission Required',
                        style: AppTheme.lightTheme.textTheme.headlineSmall
                            ?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'To scan QR codes and discover monuments, we need access to your camera.',
                        style:
                            AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                          color: Colors.white.withValues(alpha: 0.8),
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 4.h),
                      ElevatedButton(
                        onPressed: _requestCameraPermission,
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              AppTheme.lightTheme.colorScheme.primary,
                          padding: EdgeInsets.symmetric(
                            horizontal: 8.w,
                            vertical: 2.h,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'Grant Camera Permission',
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.onPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}