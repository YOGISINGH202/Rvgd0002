import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/audio_controls_widget.dart';
import './widgets/language_switcher_widget.dart';
import './widgets/monument_info_widget.dart';
import './widgets/speed_volume_controls_widget.dart';

class VoiceGuidePlayer extends StatefulWidget {
  const VoiceGuidePlayer({super.key});

  @override
  State<VoiceGuidePlayer> createState() => _VoiceGuidePlayerState();
}

class _VoiceGuidePlayerState extends State<VoiceGuidePlayer>
    with TickerProviderStateMixin {
  // Audio state
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = const Duration(minutes: 15, seconds: 30);
  double _playbackSpeed = 1.0;
  double _volume = 0.8;
  String _selectedLanguage = 'en';

  // UI state
  bool _showSpeedVolumeControls = false;
  bool _isListening = false;

  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // Mock monument data
  final Map<String, dynamic> _monumentData = {
    'id': 1,
    'name': 'Hawa Mahal',
    'location': 'Jaipur, Rajasthan',
    'description':
        'The Palace of Winds, built in 1799 by Maharaja Sawai Pratap Singh, is an iconic five-story palace with 953 small windows called jharokhas decorated with intricate latticework.',
    'imageUrl':
        'https://images.unsplash.com/photo-1599661046827-dacde6976549?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3',
    'duration': '15 min',
    'narrator': 'Dr. Rajesh Sharma',
    'audioUrl': 'https://example.com/audio/hawa-mahal-guide.mp3',
    'languages': ['en', 'hi', 'raj'],
  };

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startAudioSimulation();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeController.forward();
  }

  void _startAudioSimulation() {
    // Simulate audio playback progress
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (_isPlaying && mounted) {
        setState(() {
          _currentPosition = Duration(
            seconds: (_currentPosition.inSeconds + 1)
                .clamp(0, _totalDuration.inSeconds),
          );
        });
        if (_currentPosition >= _totalDuration) {
          setState(() {
            _isPlaying = false;
            _currentPosition = Duration.zero;
          });
          return false;
        }
      }
      return mounted;
    });
  }

  void _togglePlayPause() {
    setState(() {
      _isPlaying = !_isPlaying;
    });

    // Haptic feedback
    HapticFeedback.lightImpact();
  }

  void _skipBackward() {
    setState(() {
      _currentPosition = Duration(
        seconds: (_currentPosition.inSeconds - 15)
            .clamp(0, _totalDuration.inSeconds),
      );
    });
    HapticFeedback.selectionClick();
  }

  void _skipForward() {
    setState(() {
      _currentPosition = Duration(
        seconds: (_currentPosition.inSeconds + 15)
            .clamp(0, _totalDuration.inSeconds),
      );
    });
    HapticFeedback.selectionClick();
  }

  void _onSeek(double seconds) {
    setState(() {
      _currentPosition = Duration(seconds: seconds.round());
    });
  }

  void _onLanguageChanged(String languageCode) {
    setState(() {
      _selectedLanguage = languageCode;
    });

    // Show language change feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Language changed to ${_getLanguageName(languageCode)}'),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  String _getLanguageName(String code) {
    switch (code) {
      case 'hi':
        return 'Hindi';
      case 'raj':
        return 'Rajasthani';
      default:
        return 'English';
    }
  }

  void _onSpeedChanged(double speed) {
    setState(() {
      _playbackSpeed = speed;
    });
  }

  void _onVolumeChanged(double volume) {
    setState(() {
      _volume = volume;
    });
  }

  void _toggleSpeedVolumeControls() {
    setState(() {
      _showSpeedVolumeControls = !_showSpeedVolumeControls;
    });

    if (_showSpeedVolumeControls) {
      _slideController.forward();
    } else {
      _slideController.reverse();
    }
  }

  void _startAIListening() {
    setState(() {
      _isListening = true;
    });

    HapticFeedback.mediumImpact();

    // Simulate AI listening
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _isListening = false;
        });

        // Navigate to AI chat interface
        Navigator.pushNamed(context, '/ai-chat-interface');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onVerticalDragEnd: (details) {
          if (details.primaryVelocity != null &&
              details.primaryVelocity! > 300) {
            Navigator.of(context).pop();
          }
        },
        child: Stack(
          children: [
            // Background image
            _buildBackgroundImage(),

            // Gradient overlay
            _buildGradientOverlay(),

            // Main content
            FadeTransition(
              opacity: _fadeAnimation,
              child: Column(
                children: [
                  // Monument info header
                  Expanded(
                    flex: 2,
                    child: MonumentInfoWidget(monumentData: _monumentData),
                  ),

                  // Language switcher
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 6.w),
                    child: LanguageSwitcherWidget(
                      selectedLanguage: _selectedLanguage,
                      onLanguageChanged: _onLanguageChanged,
                    ),
                  ),

                  SizedBox(height: 2.h),

                  // Audio controls
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: AudioControlsWidget(
                      isPlaying: _isPlaying,
                      currentPosition: _currentPosition,
                      totalDuration: _totalDuration,
                      onPlayPause: _togglePlayPause,
                      onSkipBackward: _skipBackward,
                      onSkipForward: _skipForward,
                      onSeek: _onSeek,
                    ),
                  ),

                  // Control buttons row
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                    child: _buildControlButtonsRow(colorScheme),
                  ),

                  SizedBox(height: 2.h),
                ],
              ),
            ),

            // Speed and volume controls bottom sheet
            if (_showSpeedVolumeControls)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: SpeedVolumeControlsWidget(
                    playbackSpeed: _playbackSpeed,
                    volume: _volume,
                    onSpeedChanged: _onSpeedChanged,
                    onVolumeChanged: _onVolumeChanged,
                  ),
                ),
              ),

            // AI listening overlay
            if (_isListening) _buildAIListeningOverlay(colorScheme),
          ],
        ),
      ),
    );
  }

  Widget _buildBackgroundImage() {
    return Positioned.fill(
      child: CustomImageWidget(
        imageUrl: _monumentData['imageUrl'] as String,
        width: double.infinity,
        height: double.infinity,
        fit: BoxFit.cover,
      ),
    );
  }

  Widget _buildGradientOverlay() {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withValues(alpha: 0.3),
              Colors.black.withValues(alpha: 0.1),
              Colors.black.withValues(alpha: 0.7),
              Colors.black.withValues(alpha: 0.9),
            ],
            stops: const [0.0, 0.3, 0.7, 1.0],
          ),
        ),
      ),
    );
  }

  Widget _buildControlButtonsRow(ColorScheme colorScheme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // Settings button
        _buildActionButton(
          icon: 'tune',
          label: 'Settings',
          onTap: _toggleSpeedVolumeControls,
          colorScheme: colorScheme,
        ),

        // AI Guide button
        _buildActionButton(
          icon: 'mic',
          label: 'Ask AI Guide',
          onTap: _startAIListening,
          colorScheme: colorScheme,
          isPrimary: true,
        ),

        // Share button
        _buildActionButton(
          icon: 'share',
          label: 'Share',
          onTap: () => _shareExperience(),
          colorScheme: colorScheme,
        ),
      ],
    );
  }

  Widget _buildActionButton({
    required String icon,
    required String label,
    required VoidCallback onTap,
    required ColorScheme colorScheme,
    bool isPrimary = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
        decoration: BoxDecoration(
          color: isPrimary
              ? colorScheme.primary
              : Colors.white.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: isPrimary
                ? colorScheme.primary
                : Colors.white.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: icon,
              color: isPrimary ? colorScheme.onPrimary : Colors.white,
              size: 4.w,
            ),
            SizedBox(width: 2.w),
            Text(
              label,
              style: TextStyle(
                color: isPrimary ? colorScheme.onPrimary : Colors.white,
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAIListeningOverlay(ColorScheme colorScheme) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withValues(alpha: 0.8),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 20.w,
                height: 20.w,
                decoration: BoxDecoration(
                  color: colorScheme.primary,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: colorScheme.primary.withValues(alpha: 0.3),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: 'mic',
                    color: colorScheme.onPrimary,
                    size: 8.w,
                  ),
                ),
              ),
              SizedBox(height: 3.h),
              Text(
                'Listening...',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 1.h),
              Text(
                'Ask me anything about ${_monumentData['name']}',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.8),
                  fontSize: 14.sp,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _shareExperience() {
    // Simulate sharing functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Sharing your cultural experience...'),
        duration: Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
