import 'dart:async';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class VoiceInputWidget extends StatefulWidget {
  final Function(String) onVoiceMessage;
  final VoidCallback? onRecordingStart;
  final VoidCallback? onRecordingStop;

  const VoiceInputWidget({
    super.key,
    required this.onVoiceMessage,
    this.onRecordingStart,
    this.onRecordingStop,
  });

  @override
  State<VoiceInputWidget> createState() => _VoiceInputWidgetState();
}

class _VoiceInputWidgetState extends State<VoiceInputWidget>
    with TickerProviderStateMixin {
  final AudioRecorder _audioRecorder = AudioRecorder();
  bool _isRecording = false;
  bool _hasPermission = false;
  late AnimationController _pulseController;
  late AnimationController _waveController;
  Timer? _recordingTimer;
  int _recordingDuration = 0;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _checkPermissions();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    _waveController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
  }

  Future<void> _checkPermissions() async {
    final status = await Permission.microphone.status;
    setState(() {
      _hasPermission = status.isGranted;
    });
  }

  Future<void> _requestPermission() async {
    final status = await Permission.microphone.request();
    setState(() {
      _hasPermission = status.isGranted;
    });
  }

  Future<void> _startRecording() async {
    if (!_hasPermission) {
      await _requestPermission();
      if (!_hasPermission) return;
    }

    try {
      if (await _audioRecorder.hasPermission()) {
        await _audioRecorder.start(const RecordConfig(),
            path: 'voice_message.m4a');

        setState(() {
          _isRecording = true;
          _recordingDuration = 0;
        });

        _pulseController.repeat();
        _waveController.repeat();
        widget.onRecordingStart?.call();

        _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
          setState(() {
            _recordingDuration++;
          });
        });
      }
    } catch (e) {
      _showErrorSnackBar('Failed to start recording');
    }
  }

  Future<void> _stopRecording() async {
    try {
      final path = await _audioRecorder.stop();

      setState(() {
        _isRecording = false;
        _recordingDuration = 0;
      });

      _pulseController.stop();
      _waveController.stop();
      _recordingTimer?.cancel();
      widget.onRecordingStop?.call();

      if (path != null) {
        // Simulate voice-to-text conversion
        final transcription = _simulateVoiceToText();
        widget.onVoiceMessage(transcription);
      }
    } catch (e) {
      _showErrorSnackBar('Failed to stop recording');
    }
  }

  String _simulateVoiceToText() {
    final culturalQuestions = [
      'Tell me about the history of Amber Fort',
      'What are the architectural features of Hawa Mahal?',
      'Can you explain the significance of Jantar Mantar?',
      'What festivals are celebrated at City Palace?',
      'How was Mehrangarh Fort constructed?',
    ];

    return culturalQuestions[
        DateTime.now().millisecond % culturalQuestions.length];
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
      ),
    );
  }

  String _formatDuration(int seconds) {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _waveController.dispose();
    _recordingTimer?.cancel();
    _audioRecorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_isRecording) ...[
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(3.w),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _waveController,
                    builder: (context, child) {
                      return Row(
                        children: List.generate(5, (index) {
                          final delay = index * 0.2;
                          final animation = Tween<double>(
                            begin: 0.3,
                            end: 1.0,
                          ).animate(CurvedAnimation(
                            parent: _waveController,
                            curve: Interval(delay, delay + 0.4,
                                curve: Curves.easeInOut),
                          ));

                          return AnimatedBuilder(
                            animation: animation,
                            builder: (context, child) {
                              return Container(
                                width: 1.w,
                                height: 4.h * animation.value,
                                margin: EdgeInsets.symmetric(horizontal: 0.5.w),
                                decoration: BoxDecoration(
                                  color:
                                      AppTheme.lightTheme.colorScheme.primary,
                                  borderRadius: BorderRadius.circular(0.5.w),
                                ),
                              );
                            },
                          );
                        }),
                      );
                    },
                  ),
                  SizedBox(width: 4.w),
                  Text(
                    _formatDuration(_recordingDuration),
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Recording... Tap to stop',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.7),
              ),
            ),
            SizedBox(height: 2.h),
          ],
          GestureDetector(
            onTap: _isRecording ? _stopRecording : _startRecording,
            child: AnimatedBuilder(
              animation: _pulseController,
              builder: (context, child) {
                return Container(
                  width: 16.w,
                  height: 16.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _isRecording
                        ? AppTheme.lightTheme.colorScheme.error
                        : AppTheme.lightTheme.colorScheme.primary,
                    boxShadow: _isRecording
                        ? [
                            BoxShadow(
                              color: AppTheme.lightTheme.colorScheme.primary
                                  .withValues(alpha: 0.3),
                              blurRadius: 20 * (1 + _pulseController.value),
                              spreadRadius: 5 * _pulseController.value,
                            ),
                          ]
                        : [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.2),
                              blurRadius: 8,
                              offset: const Offset(0, 4),
                            ),
                          ],
                  ),
                  child: Center(
                    child: CustomIconWidget(
                      iconName: _isRecording ? 'stop' : 'mic',
                      color: Colors.white,
                      size: 8.w,
                    ),
                  ),
                );
              },
            ),
          ),
          if (!_isRecording) ...[
            SizedBox(height: 2.h),
            Text(
              'Tap to ask about Rajasthan\'s heritage',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.7),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
