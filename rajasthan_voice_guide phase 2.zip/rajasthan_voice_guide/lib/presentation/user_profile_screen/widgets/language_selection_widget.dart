import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LanguageSelectionWidget extends StatelessWidget {
  final String selectedLanguage;
  final ValueChanged<String>? onLanguageChanged;

  const LanguageSelectionWidget({
    super.key,
    required this.selectedLanguage,
    this.onLanguageChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> languages = [
      {
        'code': 'en',
        'name': 'English',
        'flag': 'https://flagcdn.com/w40/gb.png',
      },
      {
        'code': 'hi',
        'name': 'हिंदी',
        'flag': 'https://flagcdn.com/w40/in.png',
      },
      {
        'code': 'raj',
        'name': 'राजस्थानी',
        'flag': 'https://flagcdn.com/w40/in.png',
      },
    ];

    return Column(
      children: languages.map((language) {
        final isSelected = selectedLanguage == language['code'];
        return Container(
          margin: EdgeInsets.only(bottom: 2.h),
          child: InkWell(
            onTap: () => onLanguageChanged?.call(language['code'] as String),
            borderRadius: BorderRadius.circular(2.w),
            child: Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: isSelected
                    ? colorScheme.primary.withValues(alpha: 0.1)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(2.w),
                border: Border.all(
                  color: isSelected
                      ? colorScheme.primary
                      : colorScheme.outline.withValues(alpha: 0.3),
                  width: isSelected ? 2 : 1,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8.w,
                    height: 6.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(1.w),
                      border: Border.all(
                        color: colorScheme.outline.withValues(alpha: 0.3),
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(1.w),
                      child: CustomImageWidget(
                        imageUrl: language['flag'] as String,
                        width: 8.w,
                        height: 6.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Text(
                      language['name'] as String,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: isSelected
                            ? colorScheme.primary
                            : colorScheme.onSurface,
                        fontWeight:
                            isSelected ? FontWeight.w600 : FontWeight.w400,
                      ),
                    ),
                  ),
                  if (isSelected)
                    CustomIconWidget(
                      iconName: 'check_circle',
                      color: colorScheme.primary,
                      size: 5.w,
                    ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
