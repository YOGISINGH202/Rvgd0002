import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:universal_html/html.dart' as html;

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/calendar_view_widget.dart';
import './widgets/event_card_widget.dart';
import './widgets/event_detail_bottom_sheet.dart';
import './widgets/events_near_me_widget.dart';
import './widgets/filter_chips_widget.dart';

class CulturalCalendar extends StatefulWidget {
  const CulturalCalendar({super.key});

  @override
  State<CulturalCalendar> createState() => _CulturalCalendarState();
}

class _CulturalCalendarState extends State<CulturalCalendar>
    with TickerProviderStateMixin {
  late TabController _tabController;
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();
  String _selectedCategory = 'All Events';
  bool _isCalendarView = true;
  List<Map<String, dynamic>> _filteredEvents = [];

  final List<String> _categories = [
    'All Events',
    'Festivals',
    'Music',
    'Dance',
    'Food',
    'Shopping',
    'Cultural',
    'Religious',
  ];

  final List<Map<String, dynamic>> _culturalEvents = [
    {
      "id": 1,
      "title": "Pushkar Camel Fair 2024",
      "category": "Festival",
      "date": "2024-11-15",
      "time": "6:00 AM - 10:00 PM",
      "location": "Pushkar, Ajmer District",
      "distance": 2.5,
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&q=80",
      "description":
          "One of the world's largest camel fairs featuring traditional Rajasthani culture, folk performances, and camel trading.",
      "culturalSignificance":
          "This ancient fair has been celebrated for over 100 years, bringing together traders, pilgrims, and tourists to experience authentic Rajasthani traditions.",
      "hasTicketing": true,
      "ticketPrice": "₹200"
    },
    {
      "id": 2,
      "title": "Jaipur Literature Festival",
      "category": "Cultural",
      "date": "2024-11-20",
      "time": "9:00 AM - 8:00 PM",
      "location": "Diggi Palace, Jaipur",
      "distance": 15.2,
      "image":
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
      "description":
          "Asia's largest free literary festival featuring renowned authors, poets, and thinkers from around the world.",
      "culturalSignificance":
          "A celebration of literature and ideas that has put Jaipur on the global cultural map since 2006.",
      "hasTicketing": false,
      "ticketPrice": null
    },
    {
      "id": 3,
      "title": "Rajasthani Folk Music Evening",
      "category": "Music",
      "date": "2024-11-18",
      "time": "7:00 PM - 10:00 PM",
      "location": "City Palace, Udaipur",
      "distance": 8.7,
      "image":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&q=80",
      "description":
          "Traditional Rajasthani folk music performance featuring local artists and classical instruments.",
      "culturalSignificance":
          "Experience the rich musical heritage of Rajasthan with authentic folk songs passed down through generations.",
      "hasTicketing": true,
      "ticketPrice": "₹500"
    },
    {
      "id": 4,
      "title": "Ghoomar Dance Workshop",
      "category": "Dance",
      "date": "2024-11-22",
      "time": "4:00 PM - 6:00 PM",
      "location": "Jawahar Kala Kendra, Jaipur",
      "distance": 12.3,
      "image":
          "https://images.unsplash.com/photo-1594736797933-d0401ba2fe65?w=800&q=80",
      "description":
          "Learn the traditional Ghoomar dance from expert instructors in this interactive workshop.",
      "culturalSignificance":
          "Ghoomar is the traditional folk dance of Rajasthan, performed by women in flowing ghagras.",
      "hasTicketing": true,
      "ticketPrice": "₹300"
    },
    {
      "id": 5,
      "title": "Rajasthani Food Festival",
      "category": "Food",
      "date": "2024-11-25",
      "time": "12:00 PM - 10:00 PM",
      "location": "Central Park, Jaipur",
      "distance": 5.8,
      "image":
          "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&q=80",
      "description":
          "Taste authentic Rajasthani cuisine from various regions with traditional cooking demonstrations.",
      "culturalSignificance":
          "Explore the diverse culinary traditions of Rajasthan's different regions and communities.",
      "hasTicketing": true,
      "ticketPrice": "₹150"
    },
    {
      "id": 6,
      "title": "Handicrafts Bazaar",
      "category": "Shopping",
      "date": "2024-11-28",
      "time": "10:00 AM - 9:00 PM",
      "location": "Hawa Mahal Road, Jaipur",
      "distance": 7.1,
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&q=80",
      "description":
          "Shop for authentic Rajasthani handicrafts, textiles, and jewelry directly from local artisans.",
      "culturalSignificance":
          "Support local craftsmen and discover traditional Rajasthani art forms and techniques.",
      "hasTicketing": false,
      "ticketPrice": null
    },
    {
      "id": 7,
      "title": "Diwali Celebration at Amber Fort",
      "category": "Religious",
      "date": "2024-11-12",
      "time": "6:00 PM - 11:00 PM",
      "location": "Amber Fort, Jaipur",
      "distance": 18.5,
      "image":
          "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800&q=80",
      "description":
          "Grand Diwali celebration with traditional lighting, prayers, and cultural performances at the historic Amber Fort.",
      "culturalSignificance":
          "Experience Diwali in the royal setting of Amber Fort, illuminated with thousands of diyas and lights.",
      "hasTicketing": true,
      "ticketPrice": "₹400"
    },
    {
      "id": 8,
      "title": "Desert Music Festival",
      "category": "Music",
      "date": "2024-12-05",
      "time": "7:00 PM - 12:00 AM",
      "location": "Sam Sand Dunes, Jaisalmer",
      "distance": 45.2,
      "image":
          "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80",
      "description":
          "Multi-day music festival in the Thar Desert featuring international and local artists.",
      "culturalSignificance":
          "A unique blend of traditional Rajasthani music with contemporary sounds in the mystical desert setting.",
      "hasTicketing": true,
      "ticketPrice": "₹1200"
    }
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _filteredEvents = _culturalEvents;
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _filterEvents() {
    setState(() {
      if (_selectedCategory == 'All Events') {
        _filteredEvents = _culturalEvents;
      } else {
        _filteredEvents = _culturalEvents
            .where((event) => (event['category'] as String)
                .toLowerCase()
                .contains(_selectedCategory.toLowerCase().replaceAll('s', '')))
            .toList();
      }
    });
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    setState(() {
      _selectedDay = selectedDay;
      _focusedDay = focusedDay;
    });
    _showEventsForDay(selectedDay);
  }

  void _showEventsForDay(DateTime day) {
    final eventsForDay = _culturalEvents.where((event) {
      final eventDate = DateTime.parse(event['date'] as String);
      return isSameDay(eventDate, day);
    }).toList();

    if (eventsForDay.isNotEmpty) {
      _showEventDetailBottomSheet(eventsForDay.first);
    }
  }

  void _showEventDetailBottomSheet(Map<String, dynamic> event) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        minChildSize: 0.5,
        builder: (context, scrollController) => SingleChildScrollView(
          controller: scrollController,
          child: EventDetailBottomSheet(
            event: event,
            onAddToCalendar: () => _addToCalendar(event),
            onGetDirections: () => _getDirections(event),
            onBookTicket: () => _bookTicket(event),
            onShare: () => _shareEvent(event),
          ),
        ),
      ),
    );
  }

  void _addToCalendar(Map<String, dynamic> event) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Event added to calendar: ${event['title']}'),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
    );
  }

  void _getDirections(Map<String, dynamic> event) {
    Navigator.pop(context);
    final location = event['location'] as String;
    if (kIsWeb) {
      html.window.open(
        'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(location)}',
        '_blank',
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Opening directions to ${event['location']}'),
          backgroundColor: Theme.of(context).colorScheme.secondary,
        ),
      );
    }
  }

  void _bookTicket(Map<String, dynamic> event) {
    Navigator.pop(context);
    if (kIsWeb) {
      html.window.open(
        'https://www.bookmyshow.com/search?q=${Uri.encodeComponent(event['title'] as String)}',
        '_blank',
      );
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Book Tickets'),
          content: Text('Redirecting to ticket booking for ${event['title']}'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  void _shareEvent(Map<String, dynamic> event) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Sharing: ${event['title']}'),
        backgroundColor: Theme.of(context).colorScheme.tertiary,
      ),
    );
  }

  List<Map<String, dynamic>> get _nearbyEvents {
    return _culturalEvents
        .where((event) =>
            event['distance'] != null && (event['distance'] as double) <= 10)
        .toList()
      ..sort((a, b) =>
          (a['distance'] as double).compareTo(b['distance'] as double));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: CustomAppBar(
        title: 'Cultural Calendar',
        variant: CustomAppBarVariant.primary,
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                _isCalendarView = !_isCalendarView;
              });
            },
            icon: CustomIconWidget(
              iconName: _isCalendarView ? 'view_list' : 'calendar_view_month',
              color: colorScheme.onPrimary,
              size: 24,
            ),
          ),
          IconButton(
            onPressed: () =>
                Navigator.pushNamed(context, '/user-profile-screen'),
            icon: CustomIconWidget(
              iconName: 'account_circle',
              color: colorScheme.onPrimary,
              size: 24,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Filter Chips
          FilterChipsWidget(
            categories: _categories,
            selectedCategory: _selectedCategory,
            onCategorySelected: (category) {
              setState(() {
                _selectedCategory = category;
              });
              _filterEvents();
            },
          ),

          // Main Content
          Expanded(
            child: _isCalendarView ? _buildCalendarView() : _buildListView(),
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: 3,
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushNamed(context, '/home-screen');
              break;
            case 1:
              Navigator.pushNamed(context, '/explore-screen');
              break;
            case 2:
              Navigator.pushNamed(context, '/qr-code-scanner');
              break;
            case 3:
              // Current screen
              break;
            case 4:
              Navigator.pushNamed(context, '/user-profile-screen');
              break;
          }
        },
      ),
    );
  }

  Widget _buildCalendarView() {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Calendar Widget
          CalendarViewWidget(
            selectedDay: _selectedDay,
            focusedDay: _focusedDay,
            onDaySelected: _onDaySelected,
            onPageChanged: (focusedDay) {
              setState(() {
                _focusedDay = focusedDay;
              });
            },
            events: _filteredEvents,
          ),

          // Events Near Me Section
          EventsNearMeWidget(
            nearbyEvents: _nearbyEvents,
            onViewAll: () {
              setState(() {
                _isCalendarView = false;
              });
            },
            onEventTap: _showEventDetailBottomSheet,
          ),

          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildListView() {
    return Column(
      children: [
        // Events Near Me Section (collapsed)
        if (_nearbyEvents.isNotEmpty) ...[
          EventsNearMeWidget(
            nearbyEvents: _nearbyEvents.take(3).toList(),
            onViewAll: () {
              setState(() {
                _isCalendarView = true;
              });
            },
            onEventTap: _showEventDetailBottomSheet,
          ),
        ],

        // Events List
        Expanded(
          child: _filteredEvents.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'event_busy',
                        color: Theme.of(context)
                            .colorScheme
                            .onSurface
                            .withValues(alpha: 0.5),
                        size: 64,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'No events found',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurface
                                      .withValues(alpha: 0.7),
                                ),
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        'Try selecting a different category',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurface
                                  .withValues(alpha: 0.5),
                            ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: EdgeInsets.only(bottom: 2.h),
                  itemCount: _filteredEvents.length,
                  itemBuilder: (context, index) {
                    final event = _filteredEvents[index];
                    return EventCardWidget(
                      event: event,
                      onTap: () => _showEventDetailBottomSheet(event),
                      onAddToCalendar: () => _addToCalendar(event),
                      onGetDirections: () => _getDirections(event),
                      onBookTicket: event['hasTicketing'] == true
                          ? () => _bookTicket(event)
                          : null,
                    );
                  },
                ),
        ),
      ],
    );
  }
}
