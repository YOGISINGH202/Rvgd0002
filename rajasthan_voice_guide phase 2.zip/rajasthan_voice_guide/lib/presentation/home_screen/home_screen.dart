import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/continue_journey_section.dart';
import './widgets/greeting_header.dart';
import './widgets/nearby_sites_section.dart';
import './widgets/quick_actions_section.dart';
import './widgets/voice_guide_button.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  bool _isVoiceGuideActive = false;
  bool _hasNearbyAttractions = true;
  String _currentLocation = 'Jaipur, Rajasthan';
  String _preferredLanguage = 'English';
  String _userName = 'Explorer';

  // Mock data for nearby sites
  final List<Map<String, dynamic>> _nearbySites = [
    {
      "id": 1,
      "name": "Hawa Mahal",
      "image":
          "https://images.unsplash.com/photo-1599661046827-dacde6976549?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "0.8 km",
      "rating": 4.6,
      "category": "Palace",
      "description":
          "The iconic Palace of Winds with its unique honeycomb structure and 953 small windows.",
      "audioAvailable": true,
    },
    {
      "id": 2,
      "name": "City Palace",
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "1.2 km",
      "rating": 4.8,
      "category": "Palace",
      "description":
          "A magnificent palace complex showcasing Rajasthani and Mughal architecture.",
      "audioAvailable": true,
    },
    {
      "id": 3,
      "name": "Jantar Mantar",
      "image":
          "https://images.unsplash.com/photo-1609920658906-8223bd289001?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "1.5 km",
      "rating": 4.4,
      "category": "Observatory",
      "description":
          "An astronomical observatory with the world's largest stone sundial.",
      "audioAvailable": true,
    },
    {
      "id": 4,
      "name": "Amber Fort",
      "image":
          "https://images.unsplash.com/photo-1609137144813-7d9921338f24?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "11 km",
      "rating": 4.9,
      "category": "Fort",
      "description":
          "A majestic fort known for its artistic Hindu style elements and stunning mirror work.",
      "audioAvailable": true,
    },
  ];

  // Mock data for visited places
  final List<Map<String, dynamic>> _visitedPlaces = [
    {
      "id": 1,
      "name": "Jal Mahal",
      "image":
          "https://images.unsplash.com/photo-1609137144813-7d9921338f24?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "lastVisited": "2 days ago",
      "progress": 0.75,
      "totalSections": 8,
      "completedSections": 6,
    },
    {
      "id": 2,
      "name": "Nahargarh Fort",
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "lastVisited": "1 week ago",
      "progress": 1.0,
      "totalSections": 5,
      "completedSections": 5,
    },
    {
      "id": 3,
      "name": "Albert Hall Museum",
      "image":
          "https://images.unsplash.com/photo-1599661046827-dacde6976549?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "lastVisited": "2 weeks ago",
      "progress": 0.4,
      "totalSections": 10,
      "completedSections": 4,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _handleRefresh,
          color: AppTheme.lightTheme.colorScheme.primary,
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: GreetingHeader(
                  userName: _userName,
                  currentLocation: _currentLocation,
                  preferredLanguage: _preferredLanguage,
                  onLocationPressed: _handleLocationPressed,
                  onLanguagePressed: _handleLanguagePressed,
                ),
              ),
              SliverToBoxAdapter(
                child: VoiceGuideButton(
                  onPressed: _handleVoiceGuidePressed,
                  isActive: _isVoiceGuideActive,
                  hasNearbyAttractions: _hasNearbyAttractions,
                ),
              ),
              SliverToBoxAdapter(
                child: NearbySitesSection(
                  nearbySites: _nearbySites,
                  onSitePressed: _handleSitePressed,
                  onSiteLongPressed: _handleSiteLongPressed,
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(height: 3.h),
              ),
              SliverToBoxAdapter(
                child: ContinueJourneySection(
                  visitedPlaces: _visitedPlaces,
                  onPlacePressed: _handlePlacePressed,
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(height: 3.h),
              ),
              SliverToBoxAdapter(
                child: QuickActionsSection(
                  onQRScanPressed: _handleQRScanPressed,
                  onCalendarPressed: _handleCalendarPressed,
                  onPhrasesPressed: _handlePhrasesPressed,
                  onSearchPressed: _handleSearchPressed,
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(height: 10.h),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _handleSearchPressed,
        backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
        foregroundColor: AppTheme.lightTheme.colorScheme.onTertiary,
        child: CustomIconWidget(
          iconName: 'search',
          color: AppTheme.lightTheme.colorScheme.onTertiary,
          size: 6.w,
        ),
      ),
    );
  }

  Future<void> _handleRefresh() async {
    HapticFeedback.lightImpact();
    // Simulate refresh delay
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      // Update nearby attractions or any other data
      _hasNearbyAttractions = _nearbySites.isNotEmpty;
    });
  }

  void _handleVoiceGuidePressed() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isVoiceGuideActive = !_isVoiceGuideActive;
    });

    if (_isVoiceGuideActive) {
      Navigator.pushNamed(context, '/voice-guide-player');
    }
  }

  void _handleLocationPressed() {
    _showLocationBottomSheet();
  }

  void _handleLanguagePressed() {
    _showLanguageBottomSheet();
  }

  void _handleSitePressed(Map<String, dynamic> site) {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(
      context,
      '/monument-detail-screen',
      arguments: site,
    );
  }

  void _handleSiteLongPressed(Map<String, dynamic> site) {
    HapticFeedback.mediumImpact();
    _showSiteContextMenu(site);
  }

  void _handlePlacePressed(Map<String, dynamic> place) {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(
      context,
      '/monument-detail-screen',
      arguments: place,
    );
  }

  void _handleQRScanPressed() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/qr-code-scanner');
  }

  void _handleCalendarPressed() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/cultural-calendar');
  }

  void _handlePhrasesPressed() {
    HapticFeedback.lightImpact();
    // Navigate to phrases learning screen
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Local Phrases feature coming soon!'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      ),
    );
  }

  void _handleSearchPressed() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/explore-screen');
  }

  void _showLocationBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(6.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Location',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            _buildLocationOption('Jaipur, Rajasthan', 'Current Location'),
            _buildLocationOption('Udaipur, Rajasthan', 'City of Lakes'),
            _buildLocationOption('Jodhpur, Rajasthan', 'Blue City'),
            _buildLocationOption('Jaisalmer, Rajasthan', 'Golden City'),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationOption(String location, String subtitle) {
    final isSelected = location == _currentLocation;

    return ListTile(
      leading: CustomIconWidget(
        iconName: isSelected ? 'location_on' : 'location_city',
        color: isSelected
            ? AppTheme.lightTheme.colorScheme.primary
            : AppTheme.lightTheme.colorScheme.onSurface.withValues(alpha: 0.6),
        size: 6.w,
      ),
      title: Text(
        location,
        style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          color: isSelected
              ? AppTheme.lightTheme.colorScheme.primary
              : AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          color:
              AppTheme.lightTheme.colorScheme.onSurface.withValues(alpha: 0.7),
        ),
      ),
      onTap: () {
        setState(() {
          _currentLocation = location;
        });
        Navigator.pop(context);
      },
    );
  }

  void _showLanguageBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(6.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Language',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            _buildLanguageOption('English', 'EN'),
            _buildLanguageOption('Hindi', 'हि'),
            _buildLanguageOption('Rajasthani', 'राज'),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildLanguageOption(String language, String code) {
    final isSelected = language == _preferredLanguage;

    return ListTile(
      leading: Container(
        width: 10.w,
        height: 10.w,
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.lightTheme.colorScheme.primary
              : AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Text(
            code,
            style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
              color: isSelected
                  ? AppTheme.lightTheme.colorScheme.onPrimary
                  : AppTheme.lightTheme.colorScheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
      title: Text(
        language,
        style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
          fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          color: isSelected
              ? AppTheme.lightTheme.colorScheme.primary
              : AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      onTap: () {
        setState(() {
          _preferredLanguage = language;
        });
        Navigator.pop(context);
      },
    );
  }

  void _showSiteContextMenu(Map<String, dynamic> site) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(6.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              site['name'] as String,
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 3.h),
            _buildContextMenuItem(
              icon: 'directions',
              title: 'Get Directions',
              onPressed: () {
                Navigator.pop(context);
                // Handle directions
              },
            ),
            _buildContextMenuItem(
              icon: 'favorite_border',
              title: 'Save to Favorites',
              onPressed: () {
                Navigator.pop(context);
                // Handle save to favorites
              },
            ),
            _buildContextMenuItem(
              icon: 'share',
              title: 'Share with Friends',
              onPressed: () {
                Navigator.pop(context);
                // Handle share
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildContextMenuItem({
    required String icon,
    required String title,
    required VoidCallback onPressed,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 6.w,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.titleMedium,
      ),
      onTap: onPressed,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }
}
