import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class PermissionRequestWidget extends StatefulWidget {
  final VoidCallback onPermissionsGranted;

  const PermissionRequestWidget({
    super.key,
    required this.onPermissionsGranted,
  });

  @override
  State<PermissionRequestWidget> createState() =>
      _PermissionRequestWidgetState();
}

class _PermissionRequestWidgetState extends State<PermissionRequestWidget> {
  final Map<Permission, bool> _permissionStatus = {
    Permission.location: false,
    Permission.microphone: false,
    Permission.camera: false,
  };

  final List<Map<String, dynamic>> _permissions = [
    {
      'permission': Permission.location,
      'title': 'Location Access',
      'description': 'Detect nearby monuments and heritage sites automatically',
      'icon': 'location_on',
      'color': Colors.blue,
    },
    {
      'permission': Permission.microphone,
      'title': 'Microphone Access',
      'description': 'Ask voice questions to our AI cultural guide',
      'icon': 'mic',
      'color': Colors.green,
    },
    {
      'permission': Permission.camera,
      'title': 'Camera Access',
      'description': 'Scan QR codes at monuments for instant information',
      'icon': 'camera_alt',
      'color': Colors.orange,
    },
  ];

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    for (final permission in _permissionStatus.keys) {
      final status = await permission.status;
      setState(() {
        _permissionStatus[permission] = status.isGranted;
      });
    }
  }

  Future<void> _requestPermission(Permission permission) async {
    HapticFeedback.lightImpact();

    final status = await permission.request();

    setState(() {
      _permissionStatus[permission] = status.isGranted;
    });

    if (status.isPermanentlyDenied) {
      _showPermissionDialog(permission);
    }

    _checkAllPermissions();
  }

  void _checkAllPermissions() {
    final allGranted = _permissionStatus.values.every((granted) => granted);
    if (allGranted) {
      HapticFeedback.mediumImpact();
      widget.onPermissionsGranted();
    }
  }

  void _showPermissionDialog(Permission permission) {
    final permissionData = _permissions.firstWhere(
      (p) => p['permission'] == permission,
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Permission Required'),
        content: Text(
          'Please enable ${permissionData['title']} in Settings to use this feature. ${permissionData['description']}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      children: [
        Text(
          'Grant permissions for the best experience',
          textAlign: TextAlign.center,
          style: theme.textTheme.titleMedium?.copyWith(
            color: colorScheme.onSurface,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 3.h),

        // Permission cards
        ...(_permissions
            .map((permissionData) => _buildPermissionCard(permissionData))),

        SizedBox(height: 3.h),

        // Grant all button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _hasAllPermissions() ? null : _requestAllPermissions,
            style: ElevatedButton.styleFrom(
              backgroundColor: _hasAllPermissions()
                  ? colorScheme.tertiary
                  : colorScheme.primary,
              padding: EdgeInsets.symmetric(vertical: 2.h),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: _hasAllPermissions() ? 'check_circle' : 'security',
                  color: colorScheme.onPrimary,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  _hasAllPermissions()
                      ? 'All Permissions Granted!'
                      : 'Grant All Permissions',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),

        if (!_hasAllPermissions()) ...[
          SizedBox(height: 2.h),
          TextButton(
            onPressed: widget.onPermissionsGranted,
            child: Text(
              'Skip for now',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurface.withValues(alpha: 0.6),
                decoration: TextDecoration.underline,
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildPermissionCard(Map<String, dynamic> permissionData) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final permission = permissionData['permission'] as Permission;
    final isGranted = _permissionStatus[permission] ?? false;

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isGranted
            ? colorScheme.tertiary.withValues(alpha: 0.1)
            : colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isGranted
              ? colorScheme.tertiary
              : colorScheme.outline.withValues(alpha: 0.3),
          width: isGranted ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          // Icon
          Container(
            width: 12.w,
            height: 12.w,
            decoration: BoxDecoration(
              color: isGranted
                  ? colorScheme.tertiary
                  : (permissionData['color'] as Color).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: CustomIconWidget(
              iconName: permissionData['icon'],
              color:
                  isGranted ? colorScheme.onTertiary : permissionData['color'],
              size: 24,
            ),
          ),

          SizedBox(width: 4.w),

          // Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  permissionData['title'],
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: isGranted
                        ? colorScheme.tertiary
                        : colorScheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  permissionData['description'],
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isGranted
                        ? colorScheme.tertiary.withValues(alpha: 0.8)
                        : colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                ),
              ],
            ),
          ),

          // Action button
          if (!isGranted)
            TextButton(
              onPressed: () => _requestPermission(permission),
              child: Text(
                'Allow',
                style: TextStyle(
                  color: permissionData['color'],
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          else
            CustomIconWidget(
              iconName: 'check_circle',
              color: colorScheme.tertiary,
              size: 24,
            ),
        ],
      ),
    );
  }

  bool _hasAllPermissions() {
    return _permissionStatus.values.every((granted) => granted);
  }

  Future<void> _requestAllPermissions() async {
    for (final permission in _permissionStatus.keys) {
      if (!(_permissionStatus[permission] ?? false)) {
        await _requestPermission(permission);
      }
    }
  }
}
