import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class DownloadManagementWidget extends StatelessWidget {
  final List<Map<String, dynamic>> downloads;
  final double totalStorageUsed;
  final double totalStorageAvailable;
  final ValueChanged<Map<String, dynamic>>? onDownloadDelete;

  const DownloadManagementWidget({
    super.key,
    required this.downloads,
    required this.totalStorageUsed,
    required this.totalStorageAvailable,
    this.onDownloadDelete,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final storagePercentage = totalStorageUsed / totalStorageAvailable;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Storage Usage Overview
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: colorScheme.surface,
            borderRadius: BorderRadius.circular(3.w),
            border: Border.all(
              color: colorScheme.outline.withValues(alpha: 0.2),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Storage Usage',
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    '${totalStorageUsed.toStringAsFixed(1)} MB / ${totalStorageAvailable.toStringAsFixed(1)} MB',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onSurface.withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 2.h),
              Container(
                width: double.infinity,
                height: 1.h,
                decoration: BoxDecoration(
                  color: colorScheme.outline.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(0.5.h),
                ),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: storagePercentage.clamp(0.0, 1.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: storagePercentage > 0.8
                          ? colorScheme.error
                          : storagePercentage > 0.6
                              ? Colors.orange
                              : colorScheme.primary,
                      borderRadius: BorderRadius.circular(0.5.h),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 3.h),

        // Downloaded Content List
        if (downloads.isEmpty)
          Container(
            padding: EdgeInsets.all(4.w),
            child: Column(
              children: [
                CustomIconWidget(
                  iconName: 'download',
                  color: colorScheme.onSurface.withValues(alpha: 0.4),
                  size: 12.w,
                ),
                SizedBox(height: 2.h),
                Text(
                  'No offline content',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'Download audio guides for offline listening',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurface.withValues(alpha: 0.5),
                  ),
                ),
              ],
            ),
          )
        else
          ...downloads.map((download) {
            return Container(
              margin: EdgeInsets.only(bottom: 2.h),
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: colorScheme.surface,
                borderRadius: BorderRadius.circular(3.w),
                border: Border.all(
                  color: colorScheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                    child: CustomIconWidget(
                      iconName:
                          download['type'] == 'audio' ? 'headphones' : 'image',
                      color: colorScheme.primary,
                      size: 5.w,
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          download['title'] as String,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 0.5.h),
                        Row(
                          children: [
                            Text(
                              '${download['size']} MB',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: colorScheme.onSurface
                                    .withValues(alpha: 0.7),
                              ),
                            ),
                            SizedBox(width: 2.w),
                            Container(
                              width: 1,
                              height: 3.w,
                              color: colorScheme.outline.withValues(alpha: 0.3),
                            ),
                            SizedBox(width: 2.w),
                            Text(
                              download['downloadDate'] as String,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: colorScheme.onSurface
                                    .withValues(alpha: 0.7),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => onDownloadDelete?.call(download),
                    icon: CustomIconWidget(
                      iconName: 'delete_outline',
                      color: colorScheme.error,
                      size: 5.w,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
      ],
    );
  }
}
