import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class CulturalInterestsWidget extends StatelessWidget {
  final Map<String, bool> interests;
  final ValueChanged<Map<String, bool>>? onInterestsChanged;

  const CulturalInterestsWidget({
    super.key,
    required this.interests,
    this.onInterestsChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> interestOptions = [
      {
        'key': 'history',
        'name': 'History',
        'icon': 'history_edu',
      },
      {
        'key': 'spirituality',
        'name': 'Spirituality',
        'icon': 'self_improvement',
      },
      {
        'key': 'architecture',
        'name': 'Architecture',
        'icon': 'architecture',
      },
      {
        'key': 'food',
        'name': 'Food Culture',
        'icon': 'restaurant',
      },
    ];

    return Column(
      children: interestOptions.map((option) {
        final key = option['key'] as String;
        final isEnabled = interests[key] ?? false;

        return Container(
          margin: EdgeInsets.only(bottom: 2.h),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: isEnabled
                      ? colorScheme.primary.withValues(alpha: 0.1)
                      : colorScheme.surface,
                  borderRadius: BorderRadius.circular(2.w),
                  border: Border.all(
                    color: colorScheme.outline.withValues(alpha: 0.3),
                  ),
                ),
                child: CustomIconWidget(
                  iconName: option['icon'] as String,
                  color: isEnabled
                      ? colorScheme.primary
                      : colorScheme.onSurface.withValues(alpha: 0.6),
                  size: 5.w,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Text(
                  option['name'] as String,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: isEnabled
                        ? colorScheme.onSurface
                        : colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                ),
              ),
              Switch(
                value: isEnabled,
                onChanged: (value) {
                  final updatedInterests = Map<String, bool>.from(interests);
                  updatedInterests[key] = value;
                  onInterestsChanged?.call(updatedInterests);
                },
                activeColor: colorScheme.primary,
                inactiveThumbColor:
                    colorScheme.onSurface.withValues(alpha: 0.4),
                inactiveTrackColor:
                    colorScheme.onSurface.withValues(alpha: 0.2),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
