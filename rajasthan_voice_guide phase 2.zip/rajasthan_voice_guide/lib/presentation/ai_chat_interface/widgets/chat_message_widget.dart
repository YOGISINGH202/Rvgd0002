import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum MessageType { user, ai }

class ChatMessageWidget extends StatelessWidget {
  final String message;
  final MessageType type;
  final DateTime timestamp;
  final String? audioUrl;
  final List<String>? quickReplies;
  final VoidCallback? onPlayAudio;
  final Function(String)? onQuickReply;

  const ChatMessageWidget({
    super.key,
    required this.message,
    required this.type,
    required this.timestamp,
    this.audioUrl,
    this.quickReplies,
    this.onPlayAudio,
    this.onQuickReply,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isUser = type == MessageType.user;

    return Container(
      margin: EdgeInsets.symmetric(vertical: 1.h, horizontal: 4.w),
      child: Column(
        crossAxisAlignment:
            isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment:
                isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (!isUser) ...[
                CircleAvatar(
                  radius: 3.w,
                  backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                  child: CustomIconWidget(
                    iconName: 'smart_toy',
                    color: AppTheme.lightTheme.colorScheme.onPrimary,
                    size: 4.w,
                  ),
                ),
                SizedBox(width: 2.w),
              ],
              Flexible(
                child: Container(
                  constraints: BoxConstraints(maxWidth: 75.w),
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                  decoration: BoxDecoration(
                    color: isUser
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.surface,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(4.w),
                      topRight: Radius.circular(4.w),
                      bottomLeft:
                          isUser ? Radius.circular(4.w) : Radius.circular(1.w),
                      bottomRight:
                          isUser ? Radius.circular(1.w) : Radius.circular(4.w),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        message,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: isUser
                              ? AppTheme.lightTheme.colorScheme.onPrimary
                              : AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                      if (audioUrl != null) ...[
                        SizedBox(height: 1.h),
                        GestureDetector(
                          onTap: onPlayAudio,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 3.w, vertical: 1.h),
                            decoration: BoxDecoration(
                              color: (isUser
                                      ? AppTheme
                                          .lightTheme.colorScheme.onPrimary
                                      : AppTheme.lightTheme.colorScheme.primary)
                                  .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(2.w),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CustomIconWidget(
                                  iconName: 'play_arrow',
                                  color: isUser
                                      ? AppTheme
                                          .lightTheme.colorScheme.onPrimary
                                      : AppTheme.lightTheme.colorScheme.primary,
                                  size: 4.w,
                                ),
                                SizedBox(width: 2.w),
                                Text(
                                  'Play Audio',
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: isUser
                                        ? AppTheme
                                            .lightTheme.colorScheme.onPrimary
                                        : AppTheme
                                            .lightTheme.colorScheme.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              if (isUser) ...[
                SizedBox(width: 2.w),
                CircleAvatar(
                  radius: 3.w,
                  backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
                  child: CustomIconWidget(
                    iconName: 'person',
                    color: AppTheme.lightTheme.colorScheme.onSecondary,
                    size: 4.w,
                  ),
                ),
              ],
            ],
          ),
          SizedBox(height: 0.5.h),
          Padding(
            padding: EdgeInsets.only(
              left: isUser ? 0 : 12.w,
              right: isUser ? 12.w : 0,
            ),
            child: Text(
              _formatTimestamp(timestamp),
              style: theme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
              ),
            ),
          ),
          if (quickReplies != null && quickReplies!.isNotEmpty) ...[
            SizedBox(height: 1.h),
            Padding(
              padding: EdgeInsets.only(left: 12.w),
              child: Wrap(
                spacing: 2.w,
                runSpacing: 1.h,
                children: quickReplies!
                    .map((reply) => GestureDetector(
                          onTap: () => onQuickReply?.call(reply),
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 3.w, vertical: 1.h),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: AppTheme.lightTheme.colorScheme.primary,
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(5.w),
                            ),
                            child: Text(
                              reply,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.primary,
                              ),
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inHours < 1) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inDays < 1) {
      return '${difference.inHours}h ago';
    } else {
      return '${timestamp.day}/${timestamp.month}/${timestamp.year}';
    }
  }
}
