import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

enum CustomAppBarVariant {
  primary,
  transparent,
  search,
  profile,
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final CustomAppBarVariant variant;
  final List<Widget>? actions;
  final Widget? leading;
  final bool automaticallyImplyLeading;
  final bool centerTitle;
  final double? elevation;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final PreferredSizeWidget? bottom;
  final VoidCallback? onSearchTap;
  final VoidCallback? onProfileTap;
  final VoidCallback? onNotificationTap;
  final String? searchHint;
  final bool showNotificationBadge;

  const CustomAppBar({
    super.key,
    this.title,
    this.variant = CustomAppBarVariant.primary,
    this.actions,
    this.leading,
    this.automaticallyImplyLeading = true,
    this.centerTitle = true,
    this.elevation,
    this.backgroundColor,
    this.foregroundColor,
    this.bottom,
    this.onSearchTap,
    this.onProfileTap,
    this.onNotificationTap,
    this.searchHint,
    this.showNotificationBadge = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    switch (variant) {
      case CustomAppBarVariant.primary:
        return _buildPrimaryAppBar(context, theme, colorScheme);
      case CustomAppBarVariant.transparent:
        return _buildTransparentAppBar(context, theme, colorScheme);
      case CustomAppBarVariant.search:
        return _buildSearchAppBar(context, theme, colorScheme);
      case CustomAppBarVariant.profile:
        return _buildProfileAppBar(context, theme, colorScheme);
    }
  }

  Widget _buildPrimaryAppBar(
      BuildContext context, ThemeData theme, ColorScheme colorScheme) {
    return AppBar(
      title: title != null ? Text(title!) : null,
      centerTitle: centerTitle,
      elevation: elevation ?? 2.0,
      backgroundColor: backgroundColor ?? colorScheme.primary,
      foregroundColor: foregroundColor ?? colorScheme.onPrimary,
      leading: leading,
      automaticallyImplyLeading: automaticallyImplyLeading,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: theme.brightness == Brightness.light
            ? Brightness.dark
            : Brightness.light,
      ),
      actions: actions ??
          [
            IconButton(
              icon: Stack(
                children: [
                  const Icon(Icons.notifications_outlined),
                  if (showNotificationBadge)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: colorScheme.error,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 12,
                          minHeight: 12,
                        ),
                      ),
                    ),
                ],
              ),
              onPressed: onNotificationTap ?? () => _navigateToProfile(context),
            ),
            IconButton(
              icon: const Icon(Icons.account_circle_outlined),
              onPressed: onProfileTap ?? () => _navigateToProfile(context),
            ),
          ],
      bottom: bottom,
    );
  }

  Widget _buildTransparentAppBar(
      BuildContext context, ThemeData theme, ColorScheme colorScheme) {
    return AppBar(
      title: title != null ? Text(title!) : null,
      centerTitle: centerTitle,
      elevation: 0,
      backgroundColor: Colors.transparent,
      foregroundColor: foregroundColor ?? colorScheme.onSurface,
      leading: leading ??
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: colorScheme.surface.withValues(alpha: 0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.arrow_back),
            ),
            onPressed: () => Navigator.of(context).pop(),
          ),
      automaticallyImplyLeading: false,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      actions: actions ??
          [
            IconButton(
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: colorScheme.surface.withValues(alpha: 0.8),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.more_vert),
              ),
              onPressed: () {},
            ),
          ],
      bottom: bottom,
    );
  }

  Widget _buildSearchAppBar(
      BuildContext context, ThemeData theme, ColorScheme colorScheme) {
    return AppBar(
      title: Container(
        height: 40,
        decoration: BoxDecoration(
          color: colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: TextField(
          decoration: InputDecoration(
            hintText: searchHint ?? 'Search monuments, places...',
            prefixIcon: Icon(
              Icons.search,
              color: colorScheme.onSurface.withValues(alpha: 0.6),
            ),
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          ),
          onTap: onSearchTap ?? () => _navigateToExplore(context),
          readOnly: onSearchTap != null,
        ),
      ),
      centerTitle: true,
      elevation: elevation ?? 2.0,
      backgroundColor: backgroundColor ?? colorScheme.primary,
      foregroundColor: foregroundColor ?? colorScheme.onPrimary,
      leading: leading,
      automaticallyImplyLeading: automaticallyImplyLeading,
      actions: actions ??
          [
            IconButton(
              icon: const Icon(Icons.qr_code_scanner),
              onPressed: () => _navigateToQRScanner(context),
            ),
            IconButton(
              icon: const Icon(Icons.account_circle_outlined),
              onPressed: onProfileTap ?? () => _navigateToProfile(context),
            ),
          ],
      bottom: bottom,
    );
  }

  Widget _buildProfileAppBar(
      BuildContext context, ThemeData theme, ColorScheme colorScheme) {
    return AppBar(
      title: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: colorScheme.secondary,
            child: Icon(
              Icons.person,
              color: colorScheme.onSecondary,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title ?? 'Welcome Back',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: foregroundColor ?? colorScheme.onPrimary,
                  ),
                ),
                Text(
                  'Explore Cultural Heritage',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: (foregroundColor ?? colorScheme.onPrimary)
                        .withValues(alpha: 0.7),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      centerTitle: false,
      elevation: elevation ?? 2.0,
      backgroundColor: backgroundColor ?? colorScheme.primary,
      foregroundColor: foregroundColor ?? colorScheme.onPrimary,
      automaticallyImplyLeading: false,
      actions: actions ??
          [
            IconButton(
              icon: Stack(
                children: [
                  const Icon(Icons.notifications_outlined),
                  if (showNotificationBadge)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: colorScheme.error,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 12,
                          minHeight: 12,
                        ),
                      ),
                    ),
                ],
              ),
              onPressed: onNotificationTap ?? () => _navigateToProfile(context),
            ),
            IconButton(
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => _navigateToProfile(context),
            ),
          ],
      bottom: bottom,
    );
  }

  void _navigateToProfile(BuildContext context) {
    Navigator.pushNamed(context, '/user-profile-screen');
  }

  void _navigateToExplore(BuildContext context) {
    Navigator.pushNamed(context, '/explore-screen');
  }

  void _navigateToQRScanner(BuildContext context) {
    Navigator.pushNamed(context, '/qr-code-scanner');
  }

  @override
  Size get preferredSize => Size.fromHeight(
        kToolbarHeight + (bottom?.preferredSize.height ?? 0.0),
      );
}
