import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class BottomActionBar extends StatefulWidget {
  final bool isFavorite;
  final VoidCallback onFavoriteToggle;
  final VoidCallback onShare;
  final VoidCallback onRate;
  final VoidCallback onUploadPhoto;
  final VoidCallback onGetDirections;

  const BottomActionBar({
    super.key,
    required this.isFavorite,
    required this.onFavoriteToggle,
    required this.onShare,
    required this.onRate,
    required this.onUploadPhoto,
    required this.onGetDirections,
  });

  @override
  State<BottomActionBar> createState() => _BottomActionBarState();
}

class _BottomActionBarState extends State<BottomActionBar> {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            // Favorite Button
            Expanded(
              child: _buildActionButton(
                context: context,
                icon: widget.isFavorite ? 'favorite' : 'favorite_border',
                label: 'Favorite',
                onTap: widget.onFavoriteToggle,
                color: widget.isFavorite
                    ? Colors.red
                    : colorScheme.onSurface.withValues(alpha: 0.6),
                theme: theme,
                colorScheme: colorScheme,
              ),
            ),

            SizedBox(width: 2.w),

            // Share Button
            Expanded(
              child: _buildActionButton(
                context: context,
                icon: 'share',
                label: 'Share',
                onTap: widget.onShare,
                color: colorScheme.onSurface.withValues(alpha: 0.6),
                theme: theme,
                colorScheme: colorScheme,
              ),
            ),

            SizedBox(width: 2.w),

            // Rate Button
            Expanded(
              child: _buildActionButton(
                context: context,
                icon: 'star_rate',
                label: 'Rate',
                onTap: widget.onRate,
                color: colorScheme.onSurface.withValues(alpha: 0.6),
                theme: theme,
                colorScheme: colorScheme,
              ),
            ),

            SizedBox(width: 2.w),

            // Upload Photo Button
            Expanded(
              child: _buildActionButton(
                context: context,
                icon: 'add_a_photo',
                label: 'Photo',
                onTap: widget.onUploadPhoto,
                color: colorScheme.onSurface.withValues(alpha: 0.6),
                theme: theme,
                colorScheme: colorScheme,
              ),
            ),

            SizedBox(width: 4.w),

            // Get Directions Button (Primary)
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: widget.onGetDirections,
                icon: CustomIconWidget(
                  iconName: 'directions',
                  color: colorScheme.onPrimary,
                  size: 5.w,
                ),
                label: Text(
                  'Directions',
                  style: theme.textTheme.labelLarge?.copyWith(
                    color: colorScheme.onPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: colorScheme.primary,
                  padding: EdgeInsets.symmetric(vertical: 1.5.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(3.w),
                  ),
                  elevation: 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required BuildContext context,
    required String icon,
    required String label,
    required VoidCallback onTap,
    required Color color,
    required ThemeData theme,
    required ColorScheme colorScheme,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 1.h),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(2.w),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: icon,
              color: color,
              size: 6.w,
            ),
            SizedBox(height: 0.5.h),
            Text(
              label,
              style: theme.textTheme.labelSmall?.copyWith(
                color: color,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
