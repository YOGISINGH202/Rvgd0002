import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/achievement_badges_widget.dart';
import './widgets/cultural_interests_widget.dart';
import './widgets/download_management_widget.dart';
import './widgets/favorites_list_widget.dart';
import './widgets/language_selection_widget.dart';
import './widgets/preference_card_widget.dart';
import './widgets/travel_statistics_widget.dart';
import './widgets/user_header_widget.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  String selectedLanguage = 'en';
  Map<String, bool> culturalInterests = {
    'history': true,
    'spirituality': false,
    'architecture': true,
    'food': false,
  };

  // Mock user data
  final Map<String, dynamic> userData = {
    'name': 'Priya Sharma',
    'level': 'Cultural Explorer Level 3',
    'image':
        'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face',
    'progress': 0.65,
    'visitedMonuments': 24,
    'audioHours': 18,
    'culturalPoints': 1250,
  };

  final List<Map<String, dynamic>> achievements = [
    {
      'id': 1,
      'title': 'First Visit',
      'description': 'Visited your first heritage site',
      'icon': 'flag',
      'earned': true,
    },
    {
      'id': 2,
      'title': 'Audio Explorer',
      'description': 'Listened to 10 audio guides',
      'icon': 'headphones',
      'earned': true,
    },
    {
      'id': 3,
      'title': 'Culture Enthusiast',
      'description': 'Visited 20 different monuments',
      'icon': 'temple_hindu',
      'earned': true,
    },
    {
      'id': 4,
      'title': 'Social Explorer',
      'description': 'Shared 5 cultural experiences',
      'icon': 'share',
      'earned': false,
    },
    {
      'id': 5,
      'title': 'Master Explorer',
      'description': 'Visited 50 heritage sites',
      'icon': 'emoji_events',
      'earned': false,
    },
  ];

  final List<Map<String, dynamic>> favorites = [
    {
      'id': 1,
      'name': 'Hawa Mahal',
      'location': 'Jaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1599661046827-dacde6976549?w=400&h=300&fit=crop',
      'rating': 4.8,
    },
    {
      'id': 2,
      'name': 'City Palace',
      'location': 'Udaipur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
      'rating': 4.9,
    },
    {
      'id': 3,
      'name': 'Mehrangarh Fort',
      'location': 'Jodhpur, Rajasthan',
      'image':
          'https://images.unsplash.com/photo-1477587458883-47145ed94245?w=400&h=300&fit=crop',
      'rating': 4.7,
    },
  ];

  final List<Map<String, dynamic>> downloads = [
    {
      'id': 1,
      'title': 'Hawa Mahal Audio Guide',
      'type': 'audio',
      'size': 15.2,
      'downloadDate': '2 days ago',
    },
    {
      'id': 2,
      'title': 'City Palace Virtual Tour',
      'type': 'video',
      'size': 45.8,
      'downloadDate': '1 week ago',
    },
    {
      'id': 3,
      'title': 'Rajasthani Culture Guide',
      'type': 'audio',
      'size': 28.5,
      'downloadDate': '2 weeks ago',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(
        title: Text('Profile'),
        centerTitle: true,
        backgroundColor: colorScheme.surface,
        foregroundColor: colorScheme.onSurface,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _showSettingsBottomSheet,
            icon: CustomIconWidget(
              iconName: 'settings',
              color: colorScheme.onSurface,
              size: 6.w,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 2.h),

            // User Header
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: UserHeaderWidget(
                userName: userData['name'] as String,
                userLevel: userData['level'] as String,
                userImage: userData['image'] as String,
                progressValue: userData['progress'] as double,
                onEditProfile: _editProfile,
              ),
            ),

            SizedBox(height: 3.h),

            // Travel Statistics
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: TravelStatisticsWidget(
                visitedMonuments: userData['visitedMonuments'] as int,
                audioHours: userData['audioHours'] as int,
                culturalPoints: userData['culturalPoints'] as int,
              ),
            ),

            SizedBox(height: 3.h),

            // Achievement Badges
            AchievementBadgesWidget(
              achievements: achievements,
              onBadgeTap: _showAchievementDetails,
            ),

            SizedBox(height: 3.h),

            // Language Selection
            PreferenceCardWidget(
              title: 'Language Selection',
              iconName: 'language',
              content: LanguageSelectionWidget(
                selectedLanguage: selectedLanguage,
                onLanguageChanged: (language) {
                  setState(() {
                    selectedLanguage = language;
                  });
                },
              ),
            ),

            // Cultural Interests
            PreferenceCardWidget(
              title: 'Cultural Interests',
              iconName: 'interests',
              content: CulturalInterestsWidget(
                interests: culturalInterests,
                onInterestsChanged: (interests) {
                  setState(() {
                    culturalInterests = interests;
                  });
                },
              ),
            ),

            // Audio Settings
            PreferenceCardWidget(
              title: 'Audio Settings',
              iconName: 'volume_up',
              content: _buildAudioSettings(),
              onTap: _showAudioSettingsDialog,
            ),

            // My Favorites
            PreferenceCardWidget(
              title: 'My Favorites',
              iconName: 'favorite',
              content: FavoritesListWidget(
                favorites: favorites,
                onFavoriteRemove: _removeFavorite,
                onFavoriteTap: _openFavoriteDetail,
              ),
            ),

            // Download Management
            PreferenceCardWidget(
              title: 'Download Management',
              iconName: 'download',
              content: DownloadManagementWidget(
                downloads: downloads,
                totalStorageUsed: 89.5,
                totalStorageAvailable: 500.0,
                onDownloadDelete: _deleteDownload,
              ),
            ),

            SizedBox(height: 3.h),

            // Account Actions
            _buildAccountActions(),

            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  Widget _buildAudioSettings() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Playback Speed',
              style: theme.textTheme.bodyMedium,
            ),
            Text(
              '1.0x',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Voice Gender',
              style: theme.textTheme.bodyMedium,
            ),
            Text(
              'Female',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Auto-download',
              style: theme.textTheme.bodyMedium,
            ),
            Switch(
              value: true,
              onChanged: (value) {},
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAccountActions() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        children: [
          _buildActionTile(
            'Privacy Settings',
            'privacy_tip',
            () => _navigateToPrivacySettings(),
          ),
          _buildActionTile(
            'Notification Preferences',
            'notifications',
            () => _navigateToNotificationSettings(),
          ),
          _buildActionTile(
            'Data Sync',
            'sync',
            () => _showDataSyncDialog(),
          ),
          _buildActionTile(
            'Help & Support',
            'help',
            () => _navigateToHelp(),
          ),
          SizedBox(height: 2.h),
          Container(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: _showLogoutDialog,
              style: OutlinedButton.styleFrom(
                foregroundColor: colorScheme.error,
                side: BorderSide(color: colorScheme.error),
                padding: EdgeInsets.symmetric(vertical: 3.h),
              ),
              child: Text('Logout'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionTile(String title, String iconName, VoidCallback onTap) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      child: ListTile(
        onTap: onTap,
        leading: CustomIconWidget(
          iconName: iconName,
          color: colorScheme.onSurface.withValues(alpha: 0.7),
          size: 6.w,
        ),
        title: Text(
          title,
          style: theme.textTheme.bodyMedium,
        ),
        trailing: CustomIconWidget(
          iconName: 'chevron_right',
          color: colorScheme.onSurface.withValues(alpha: 0.5),
          size: 5.w,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(2.w),
        ),
      ),
    );
  }

  void _editProfile() {
    // Navigate to edit profile screen or show dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Profile'),
        content:
            Text('Profile editing functionality will be implemented here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showAchievementDetails(Map<String, dynamic> achievement) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(achievement['title'] as String),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: achievement['icon'] as String,
              color: achievement['earned'] as bool
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withValues(alpha: 0.4),
              size: 15.w,
            ),
            SizedBox(height: 2.h),
            Text(
              achievement['description'] as String,
              textAlign: TextAlign.center,
            ),
            if (achievement['earned'] as bool) ...[
              SizedBox(height: 2.h),
              Text(
                'Congratulations! You\'ve earned this badge.',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _removeFavorite(Map<String, dynamic> favorite) {
    setState(() {
      favorites.removeWhere((f) => f['id'] == favorite['id']);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${favorite['name']} removed from favorites'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            setState(() {
              favorites.add(favorite);
            });
          },
        ),
      ),
    );
  }

  void _openFavoriteDetail(Map<String, dynamic> favorite) {
    Navigator.pushNamed(context, '/monument-detail-screen');
  }

  void _deleteDownload(Map<String, dynamic> download) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Download'),
        content:
            Text('Are you sure you want to delete "${download['title']}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                downloads.removeWhere((d) => d['id'] == download['id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Download deleted')),
              );
            },
            child: Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showAudioSettingsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Audio Settings'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Detailed audio settings will be implemented here.'),
            SizedBox(height: 2.h),
            Text('• Playback speed control'),
            Text('• Voice gender selection'),
            Text('• Auto-download preferences'),
            Text('• Audio quality settings'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showSettingsBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(4.w)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .outline
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(0.25.h),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Settings',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'dark_mode',
                color: Theme.of(context).colorScheme.onSurface,
                size: 6.w,
              ),
              title: Text('Dark Mode'),
              trailing: Switch(
                value: false,
                onChanged: (value) {},
              ),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'backup',
                color: Theme.of(context).colorScheme.onSurface,
                size: 6.w,
              ),
              title: Text('Backup Data'),
              onTap: () {
                Navigator.pop(context);
                _showDataSyncDialog();
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'info',
                color: Theme.of(context).colorScheme.onSurface,
                size: 6.w,
              ),
              title: Text('About App'),
              onTap: () {
                Navigator.pop(context);
                _showAboutDialog();
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _navigateToPrivacySettings() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Privacy Settings'),
        content: Text('Privacy settings screen will be implemented here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  void _navigateToNotificationSettings() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Notification Preferences'),
        content: Text('Notification settings screen will be implemented here.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showDataSyncDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Data Synchronization'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Sync your data across devices:'),
            SizedBox(height: 2.h),
            Text('• Profile information'),
            Text('• Favorites and bookmarks'),
            Text('• Achievement progress'),
            Text('• Audio preferences'),
            SizedBox(height: 2.h),
            Text('Last sync: 2 hours ago'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Data synced successfully')),
              );
            },
            child: Text('Sync Now'),
          ),
        ],
      ),
    );
  }

  void _navigateToHelp() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Help & Support'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Need help? Contact us:'),
            SizedBox(height: 2.h),
            Text('📧 support@rajasthanvoiceguide.com'),
            Text('📞 +91 98765 43210'),
            SizedBox(height: 2.h),
            Text('Or visit our FAQ section for common questions.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Open FAQ or contact form
            },
            child: Text('Visit FAQ'),
          ),
        ],
      ),
    );
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('About Rajasthan Voice Guide'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Version 1.2.0'),
            SizedBox(height: 1.h),
            Text(
                'Your AI-powered cultural companion for exploring Rajasthan\'s rich heritage.'),
            SizedBox(height: 2.h),
            Text('© 2024 Rajasthan Voice Guide'),
            Text('All rights reserved.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Logout'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you sure you want to logout?'),
            SizedBox(height: 2.h),
            Text('Your data will be saved and you can login again anytime.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Perform logout
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/splash-screen',
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            child: Text('Logout'),
          ),
        ],
      ),
    );
  }
}
