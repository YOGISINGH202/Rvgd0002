import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class ContentSectionCard extends StatefulWidget {
  final String title;
  final String content;
  final IconData icon;
  final bool initiallyExpanded;

  const ContentSectionCard({
    super.key,
    required this.title,
    required this.content,
    required this.icon,
    this.initiallyExpanded = false,
  });

  @override
  State<ContentSectionCard> createState() => _ContentSectionCardState();
}

class _ContentSectionCardState extends State<ContentSectionCard>
    with SingleTickerProviderStateMixin {
  late bool _isExpanded;
  late AnimationController _animationController;
  late Animation<double> _expandAnimation;

  @override
  void initState() {
    super.initState();
    _isExpanded = widget.initiallyExpanded;
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _expandAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );

    if (_isExpanded) {
      _animationController.value = 1.0;
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _toggleExpansion() {
    setState(() {
      _isExpanded = !_isExpanded;
      if (_isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          GestureDetector(
            onTap: _toggleExpansion,
            child: Container(
              padding: EdgeInsets.all(4.w),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                    child: CustomIconWidget(
                      iconName: widget.icon.codePoint.toString(),
                      color: colorScheme.primary,
                      size: 5.w,
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Text(
                      widget.title,
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: colorScheme.onSurface,
                      ),
                    ),
                  ),
                  AnimatedRotation(
                    turns: _isExpanded ? 0.5 : 0.0,
                    duration: const Duration(milliseconds: 300),
                    child: CustomIconWidget(
                      iconName: 'keyboard_arrow_down',
                      color: colorScheme.onSurface.withValues(alpha: 0.6),
                      size: 6.w,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Content
          SizeTransition(
            sizeFactor: _expandAnimation,
            child: Container(
              padding: EdgeInsets.fromLTRB(4.w, 0, 4.w, 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Divider(
                    color: colorScheme.outline.withValues(alpha: 0.2),
                    thickness: 1,
                  ),

                  SizedBox(height: 2.h),

                  GestureDetector(
                    onLongPress: () => _showTranslationOptions(context),
                    child: Text(
                      widget.content,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: colorScheme.onSurface.withValues(alpha: 0.8),
                        height: 1.6,
                      ),
                    ),
                  ),

                  SizedBox(height: 2.h),

                  // Action Buttons
                  Row(
                    children: [
                      TextButton.icon(
                        onPressed: () => _showTranslationOptions(context),
                        icon: CustomIconWidget(
                          iconName: 'translate',
                          color: colorScheme.primary,
                          size: 4.w,
                        ),
                        label: Text(
                          'Translate',
                          style: theme.textTheme.labelLarge?.copyWith(
                            color: colorScheme.primary,
                          ),
                        ),
                      ),
                      SizedBox(width: 2.w),
                      TextButton.icon(
                        onPressed: () => _readAloud(widget.content),
                        icon: CustomIconWidget(
                          iconName: 'record_voice_over',
                          color: colorScheme.primary,
                          size: 4.w,
                        ),
                        label: Text(
                          'Read Aloud',
                          style: theme.textTheme.labelLarge?.copyWith(
                            color: colorScheme.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showTranslationOptions(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    showModalBottomSheet(
      context: context,
      backgroundColor: colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(5.w)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Translate to',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                color: colorScheme.onSurface,
              ),
            ),
            SizedBox(height: 2.h),
            ...['Hindi', 'English', 'Rajasthani', 'French', 'German'].map(
              (language) => ListTile(
                leading: CustomIconWidget(
                  iconName: 'language',
                  color: colorScheme.primary,
                  size: 5.w,
                ),
                title: Text(
                  language,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: colorScheme.onSurface,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _translateContent(language);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _translateContent(String language) {
    // Implementation for translation
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Translating to $language...'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _readAloud(String content) {
    // Implementation for text-to-speech
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Reading content aloud...'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
