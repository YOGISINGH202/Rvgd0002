import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MapViewWidget extends StatefulWidget {
  final List<Map<String, dynamic>> monuments;
  final Function(Map<String, dynamic>)? onMonumentTap;

  const MapViewWidget({
    super.key,
    required this.monuments,
    this.onMonumentTap,
  });

  @override
  State<MapViewWidget> createState() => _MapViewWidgetState();
}

class _MapViewWidgetState extends State<MapViewWidget> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  Map<String, dynamic>? _selectedMonument;

  // Default location - Jaipur, Rajasthan
  static const CameraPosition _initialPosition = CameraPosition(
    target: LatLng(26.9124, 75.7873),
    zoom: 12.0,
  );

  @override
  void initState() {
    super.initState();
    _createMarkers();
  }

  void _createMarkers() {
    _markers = widget.monuments.map((monument) {
      return Marker(
        markerId: MarkerId(monument["id"].toString()),
        position: LatLng(
          monument["latitude"] as double,
          monument["longitude"] as double,
        ),
        infoWindow: InfoWindow(
          title: monument["name"] as String,
          snippet: monument["category"] as String,
        ),
        onTap: () => _onMarkerTapped(monument),
      );
    }).toSet();
  }

  void _onMarkerTapped(Map<String, dynamic> monument) {
    setState(() {
      _selectedMonument = monument;
    });
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      height: 100.h - 20.h, // Full height minus app bar and bottom navigation
      child: Stack(
        children: [
          // Google Map
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: _initialPosition,
            markers: _markers,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            compassEnabled: true,
            buildingsEnabled: true,
            trafficEnabled: false,
            onTap: (_) {
              setState(() {
                _selectedMonument = null;
              });
            },
          ),
          // Custom controls
          Positioned(
            top: 2.h,
            right: 4.w,
            child: Column(
              children: [
                _buildMapControl(
                  context,
                  'my_location',
                  'My Location',
                  () => _goToCurrentLocation(),
                  colorScheme,
                ),
                SizedBox(height: 2.h),
                _buildMapControl(
                  context,
                  'zoom_in',
                  'Zoom In',
                  () => _zoomIn(),
                  colorScheme,
                ),
                SizedBox(height: 1.h),
                _buildMapControl(
                  context,
                  'zoom_out',
                  'Zoom Out',
                  () => _zoomOut(),
                  colorScheme,
                ),
              ],
            ),
          ),
          // Monument preview card
          if (_selectedMonument != null)
            Positioned(
              bottom: 2.h,
              left: 4.w,
              right: 4.w,
              child: _buildMonumentPreviewCard(
                context,
                _selectedMonument!,
                theme,
                colorScheme,
              ),
            ),
          // Legend
          Positioned(
            top: 2.h,
            left: 4.w,
            child: Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: colorScheme.surface.withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: colorScheme.shadow.withValues(alpha: 0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Heritage Sites',
                    style: theme.textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: colorScheme.onSurface,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    '${widget.monuments.length} locations',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onSurface.withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapControl(
    BuildContext context,
    String iconName,
    String tooltip,
    VoidCallback onTap,
    ColorScheme colorScheme,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: colorScheme.shadow.withValues(alpha: 0.1),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: CustomIconWidget(
          iconName: iconName,
          color: colorScheme.primary,
          size: 5.w,
        ),
      ),
    );
  }

  Widget _buildMonumentPreviewCard(
    BuildContext context,
    Map<String, dynamic> monument,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return GestureDetector(
      onTap: () => widget.onMonumentTap?.call(monument),
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: colorScheme.shadow.withValues(alpha: 0.2),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            // Image
            Container(
              width: 20.w,
              height: 15.w,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: colorScheme.surfaceContainerHighest,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: CustomImageWidget(
                  imageUrl: monument["image"] as String,
                  width: 20.w,
                  height: 15.w,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(width: 3.w),
            // Content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    monument["name"] as String,
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: colorScheme.onSurface,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: colorScheme.primary.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          monument["category"] as String,
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'star',
                            color: Colors.amber,
                            size: 3.w,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            monument["rating"].toString(),
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: colorScheme.onSurface,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 1.h),
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'location_on',
                        color: colorScheme.onSurface.withValues(alpha: 0.6),
                        size: 3.w,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        monument["distance"] as String,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: colorScheme.onSurface.withValues(alpha: 0.6),
                        ),
                      ),
                      const Spacer(),
                      CustomIconWidget(
                        iconName: 'arrow_forward',
                        color: colorScheme.primary,
                        size: 4.w,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _goToCurrentLocation() async {
    if (_mapController != null) {
      // In a real app, you would get the actual current location
      // For demo purposes, we'll center on Jaipur
      await _mapController!.animateCamera(
        CameraUpdate.newCameraPosition(_initialPosition),
      );
    }
  }

  void _zoomIn() async {
    if (_mapController != null) {
      await _mapController!.animateCamera(CameraUpdate.zoomIn());
    }
  }

  void _zoomOut() async {
    if (_mapController != null) {
      await _mapController!.animateCamera(CameraUpdate.zoomOut());
    }
  }
}
