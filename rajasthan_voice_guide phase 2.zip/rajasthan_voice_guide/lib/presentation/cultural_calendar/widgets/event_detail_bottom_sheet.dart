import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EventDetailBottomSheet extends StatelessWidget {
  final Map<String, dynamic> event;
  final VoidCallback? onAddToCalendar;
  final VoidCallback? onGetDirections;
  final VoidCallback? onBookTicket;
  final VoidCallback? onShare;

  const EventDetailBottomSheet({
    super.key,
    required this.event,
    this.onAddToCalendar,
    this.onGetDirections,
    this.onBookTicket,
    this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle Bar
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.symmetric(vertical: 2.h),
            decoration: BoxDecoration(
              color: colorScheme.onSurface.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Event Image
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: CustomImageWidget(
              imageUrl: event['image'] as String,
              width: 90.w,
              height: 20.h,
              fit: BoxFit.cover,
            ),
          ),

          Padding(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Category and Share Button
                Row(
                  children: [
                    Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                      decoration: BoxDecoration(
                        color: _getCategoryColor(event['category'] as String)
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        event['category'] as String,
                        style: theme.textTheme.labelMedium?.copyWith(
                          color: _getCategoryColor(event['category'] as String),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: onShare,
                      icon: CustomIconWidget(
                        iconName: 'share',
                        color: colorScheme.onSurface.withValues(alpha: 0.7),
                        size: 24,
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 2.h),

                // Event Title
                Text(
                  event['title'] as String,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: colorScheme.onSurface,
                  ),
                ),

                SizedBox(height: 2.h),

                // Date and Time
                _buildInfoRow(
                  context,
                  'schedule',
                  'Date & Time',
                  '${_formatFullDate(event['date'] as String)} • ${event['time'] as String}',
                  theme,
                  colorScheme,
                ),

                SizedBox(height: 1.5.h),

                // Location
                _buildInfoRow(
                  context,
                  'location_on',
                  'Location',
                  event['location'] as String,
                  theme,
                  colorScheme,
                ),

                if (event['distance'] != null) ...[
                  SizedBox(height: 1.5.h),
                  _buildInfoRow(
                    context,
                    'directions',
                    'Distance',
                    '${event['distance']} km from your location',
                    theme,
                    colorScheme,
                  ),
                ],

                SizedBox(height: 2.h),

                // Description
                Text(
                  'About this Event',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: colorScheme.onSurface,
                  ),
                ),

                SizedBox(height: 1.h),

                Text(
                  event['description'] as String,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onSurface.withValues(alpha: 0.8),
                    height: 1.5,
                  ),
                ),

                if (event['culturalSignificance'] != null) ...[
                  SizedBox(height: 2.h),
                  Text(
                    'Cultural Significance',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: colorScheme.onSurface,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    event['culturalSignificance'] as String,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: colorScheme.onSurface.withValues(alpha: 0.8),
                      height: 1.5,
                    ),
                  ),
                ],

                SizedBox(height: 3.h),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: onAddToCalendar,
                        icon: CustomIconWidget(
                          iconName: 'event',
                          color: colorScheme.primary,
                          size: 18,
                        ),
                        label: Text('Add to Calendar'),
                        style: OutlinedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                        ),
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: onGetDirections,
                        icon: CustomIconWidget(
                          iconName: 'directions',
                          color: colorScheme.secondary,
                          size: 18,
                        ),
                        label: Text('Directions'),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: colorScheme.secondary),
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                        ),
                      ),
                    ),
                  ],
                ),

                if (event['hasTicketing'] == true) ...[
                  SizedBox(height: 1.5.h),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: onBookTicket,
                      icon: CustomIconWidget(
                        iconName: 'confirmation_number',
                        color: colorScheme.onPrimary,
                        size: 18,
                      ),
                      label: Text('Book Tickets - ${event['ticketPrice']}'),
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 1.5.h),
                      ),
                    ),
                  ),
                ],

                SizedBox(height: 2.h),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(
    BuildContext context,
    String iconName,
    String title,
    String value,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomIconWidget(
          iconName: iconName,
          color: colorScheme.primary,
          size: 20,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: theme.textTheme.labelMedium?.copyWith(
                  color: colorScheme.onSurface.withValues(alpha: 0.7),
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 0.5.h),
              Text(
                value,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: colorScheme.onSurface,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'festival':
        return const Color(0xFFFF6B35);
      case 'music':
        return const Color(0xFF8B4513);
      case 'dance':
        return const Color(0xFFD4AF37);
      case 'food':
        return const Color(0xFFA0522D);
      case 'shopping':
        return const Color(0xFFCD853F);
      default:
        return const Color(0xFFB8860B);
    }
  }

  String _formatFullDate(String dateString) {
    final date = DateTime.parse(dateString);
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    final days = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];
    return '${days[date.weekday % 7]}, ${date.day} ${months[date.month - 1]} ${date.year}';
  }
}
