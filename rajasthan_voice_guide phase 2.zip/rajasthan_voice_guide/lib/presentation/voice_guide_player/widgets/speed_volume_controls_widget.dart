import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class SpeedVolumeControlsWidget extends StatelessWidget {
  final double playbackSpeed;
  final double volume;
  final Function(double) onSpeedChanged;
  final Function(double) onVolumeChanged;

  const SpeedVolumeControlsWidget({
    super.key,
    required this.playbackSpeed,
    required this.volume,
    required this.onSpeedChanged,
    required this.onVolumeChanged,
  });

  static const List<double> speedOptions = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle bar
          Center(
            child: Container(
              width: 10.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: colorScheme.outline.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          SizedBox(height: 3.h),

          // Speed control section
          _buildSpeedControl(theme, colorScheme),
          SizedBox(height: 3.h),

          // Volume control section
          _buildVolumeControl(theme, colorScheme),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildSpeedControl(ThemeData theme, ColorScheme colorScheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: 'speed',
              color: colorScheme.primary,
              size: 5.w,
            ),
            SizedBox(width: 2.w),
            Text(
              'Playback Speed',
              style: theme.textTheme.titleSmall?.copyWith(
                color: colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),

        // Speed options
        Wrap(
          spacing: 2.w,
          runSpacing: 1.h,
          children: speedOptions.map((speed) {
            final isSelected = (playbackSpeed - speed).abs() < 0.01;
            return GestureDetector(
              onTap: () => onSpeedChanged(speed),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: isSelected ? colorScheme.primary : colorScheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? colorScheme.primary
                        : colorScheme.outline.withValues(alpha: 0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  '${speed}x',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isSelected
                        ? colorScheme.onPrimary
                        : colorScheme.onSurface,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildVolumeControl(ThemeData theme, ColorScheme colorScheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: 'volume_up',
              color: colorScheme.primary,
              size: 5.w,
            ),
            SizedBox(width: 2.w),
            Text(
              'Volume',
              style: theme.textTheme.titleSmall?.copyWith(
                color: colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),

        // Volume slider
        Row(
          children: [
            CustomIconWidget(
              iconName: 'volume_down',
              color: colorScheme.onSurface.withValues(alpha: 0.6),
              size: 4.w,
            ),
            Expanded(
              child: SliderTheme(
                data: SliderThemeData(
                  trackHeight: 4,
                  thumbShape:
                      const RoundSliderThumbShape(enabledThumbRadius: 8),
                  overlayShape:
                      const RoundSliderOverlayShape(overlayRadius: 16),
                  activeTrackColor: colorScheme.primary,
                  inactiveTrackColor:
                      colorScheme.primary.withValues(alpha: 0.3),
                  thumbColor: colorScheme.primary,
                  overlayColor: colorScheme.primary.withValues(alpha: 0.2),
                ),
                child: Slider(
                  value: volume,
                  min: 0.0,
                  max: 1.0,
                  onChanged: onVolumeChanged,
                ),
              ),
            ),
            CustomIconWidget(
              iconName: 'volume_up',
              color: colorScheme.onSurface.withValues(alpha: 0.6),
              size: 4.w,
            ),
          ],
        ),
      ],
    );
  }
}
