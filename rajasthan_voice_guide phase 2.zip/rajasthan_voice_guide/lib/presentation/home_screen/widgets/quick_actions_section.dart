import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QuickActionsSection extends StatelessWidget {
  final VoidCallback? onQRScanPressed;
  final VoidCallback? onCalendarPressed;
  final VoidCallback? onPhrasesPressed;
  final VoidCallback? onSearchPressed;

  const QuickActionsSection({
    super.key,
    this.onQRScanPressed,
    this.onCalendarPressed,
    this.onPhrasesPressed,
    this.onSearchPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Text(
            'Quick Actions',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            children: [
              Expanded(
                child: _buildActionTile(
                  icon: 'qr_code_scanner',
                  title: 'QR Scanner',
                  subtitle: 'Scan monuments',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  onPressed: onQRScanPressed,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildActionTile(
                  icon: 'calendar_today',
                  title: 'Cultural Calendar',
                  subtitle: 'Events & festivals',
                  color: AppTheme.lightTheme.colorScheme.secondary,
                  onPressed: onCalendarPressed,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 2.h),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Row(
            children: [
              Expanded(
                child: _buildActionTile(
                  icon: 'translate',
                  title: 'Local Phrases',
                  subtitle: 'Learn Rajasthani',
                  color: Colors.orange,
                  onPressed: onPhrasesPressed,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildActionTile(
                  icon: 'search',
                  title: 'Voice Search',
                  subtitle: 'Find places',
                  color: Colors.green,
                  onPressed: onSearchPressed,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildActionTile({
    required String icon,
    required String title,
    required String subtitle,
    required Color color,
    VoidCallback? onPressed,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color:
                  AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: CustomIconWidget(
                iconName: icon,
                color: color,
                size: 6.w,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 0.5.h),
            Text(
              subtitle,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.7),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
