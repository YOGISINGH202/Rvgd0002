import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class MonumentInfoWidget extends StatelessWidget {
  final Map<String, dynamic> monumentData;

  const MonumentInfoWidget({
    super.key,
    required this.monumentData,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withValues(alpha: 0.7),
            Colors.black.withValues(alpha: 0.3),
            Colors.transparent,
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with close button
            _buildHeader(context, colorScheme),
            SizedBox(height: 2.h),

            // Monument title and location
            _buildMonumentTitle(theme, colorScheme),
            SizedBox(height: 1.h),

            // Monument description
            _buildMonumentDescription(theme),
            SizedBox(height: 2.h),

            // Audio info
            _buildAudioInfo(theme, colorScheme),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, ColorScheme colorScheme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'Voice Guide',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              shape: BoxShape.circle,
            ),
            child: CustomIconWidget(
              iconName: 'close',
              color: Colors.white,
              size: 5.w,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMonumentTitle(ThemeData theme, ColorScheme colorScheme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          monumentData['name'] as String? ?? 'Unknown Monument',
          style: theme.textTheme.headlineSmall?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 0.5.h),
        Row(
          children: [
            CustomIconWidget(
              iconName: 'location_on',
              color: Colors.white.withValues(alpha: 0.8),
              size: 4.w,
            ),
            SizedBox(width: 1.w),
            Expanded(
              child: Text(
                monumentData['location'] as String? ?? 'Rajasthan, India',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: Colors.white.withValues(alpha: 0.8),
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMonumentDescription(ThemeData theme) {
    final description = monumentData['description'] as String? ??
        'Discover the rich history and cultural significance of this magnificent heritage site through our immersive audio guide.';

    return Text(
      description,
      style: theme.textTheme.bodyMedium?.copyWith(
        color: Colors.white.withValues(alpha: 0.9),
        height: 1.4,
      ),
      maxLines: 3,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildAudioInfo(ThemeData theme, ColorScheme colorScheme) {
    final duration = monumentData['duration'] as String? ?? '15 min';
    final narrator = monumentData['narrator'] as String? ?? 'Cultural Expert';

    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'access_time',
                  color: Colors.white.withValues(alpha: 0.8),
                  size: 4.w,
                ),
                SizedBox(width: 2.w),
                Text(
                  duration,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.white.withValues(alpha: 0.8),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'person',
                  color: Colors.white.withValues(alpha: 0.8),
                  size: 4.w,
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Text(
                    narrator,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: Colors.white.withValues(alpha: 0.8),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
