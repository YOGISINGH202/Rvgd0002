import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TorchControlWidget extends StatelessWidget {
  final bool isTorchOn;
  final bool isVisible;
  final VoidCallback onToggle;

  const TorchControlWidget({
    super.key,
    required this.isTorchOn,
    required this.isVisible,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: isVisible ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 300),
      child: AnimatedScale(
        scale: isVisible ? 1.0 : 0.8,
        duration: const Duration(milliseconds: 300),
        child: GestureDetector(
          onTap: isVisible ? onToggle : null,
          child: Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: isTorchOn
                  ? AppTheme.lightTheme.colorScheme.primary
                  : Colors.black.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12),
              border: isTorchOn
                  ? Border.all(
                      color: AppTheme.lightTheme.colorScheme.primary
                          .withValues(alpha: 0.3),
                      width: 2,
                    )
                  : null,
              boxShadow: [
                BoxShadow(
                  color: isTorchOn
                      ? AppTheme.lightTheme.colorScheme.primary
                          .withValues(alpha: 0.3)
                      : Colors.black.withValues(alpha: 0.2),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: CustomIconWidget(
              iconName: isTorchOn ? 'flash_on' : 'flash_off',
              color: isTorchOn
                  ? AppTheme.lightTheme.colorScheme.onPrimary
                  : Colors.white,
              size: 6.w,
            ),
          ),
        ),
      ),
    );
  }
}
