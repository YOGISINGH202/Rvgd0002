import 'package:flutter/material.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/voice_guide_player/voice_guide_player.dart';
import '../presentation/user_profile_screen/user_profile_screen.dart';
import '../presentation/onboarding_flow/onboarding_flow.dart';
import '../presentation/cultural_calendar/cultural_calendar.dart';
import '../presentation/qr_code_scanner/qr_code_scanner.dart';
import '../presentation/home_screen/home_screen.dart';
import '../presentation/explore_screen/explore_screen.dart';
import '../presentation/ai_chat_interface/ai_chat_interface.dart';
import '../presentation/monument_detail_screen/monument_detail_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String splash = '/splash-screen';
  static const String voiceGuidePlayer = '/voice-guide-player';
  static const String userProfile = '/user-profile-screen';
  static const String onboardingFlow = '/onboarding-flow';
  static const String culturalCalendar = '/cultural-calendar';
  static const String qrCodeScanner = '/qr-code-scanner';
  static const String home = '/home-screen';
  static const String explore = '/explore-screen';
  static const String aiChatInterface = '/ai-chat-interface';
  static const String monumentDetail = '/monument-detail-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    splash: (context) => const SplashScreen(),
    voiceGuidePlayer: (context) => const VoiceGuidePlayer(),
    userProfile: (context) => const UserProfileScreen(),
    onboardingFlow: (context) => const OnboardingFlow(),
    culturalCalendar: (context) => const CulturalCalendar(),
    qrCodeScanner: (context) => const QrCodeScanner(),
    home: (context) => const HomeScreen(),
    explore: (context) => const ExploreScreen(),
    aiChatInterface: (context) => const AiChatInterface(),
    monumentDetail: (context) => const MonumentDetailScreen(),
    // TODO: Add your other routes here
  };
}
