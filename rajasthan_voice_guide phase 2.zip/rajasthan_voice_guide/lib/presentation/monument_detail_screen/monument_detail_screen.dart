import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/bottom_action_bar.dart';
import './widgets/content_section_card.dart';
import './widgets/interactive_timeline.dart';
import './widgets/monument_header.dart';
import './widgets/monument_hero_carousel.dart';
import './widgets/photo_gallery_section.dart';
import './widgets/related_monuments_section.dart';

class MonumentDetailScreen extends StatefulWidget {
  const MonumentDetailScreen({super.key});

  @override
  State<MonumentDetailScreen> createState() => _MonumentDetailScreenState();
}

class _MonumentDetailScreenState extends State<MonumentDetailScreen> {
  final ScrollController _scrollController = ScrollController();
  bool _isFavorite = false;
  bool _showAppBarTitle = false;

  // Mock data for the monument
  final List<String> _monumentImages = [
    "https://images.unsplash.com/photo-1564507592333-c60657eea523?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "https://images.unsplash.com/photo-1548013146-72479768bada?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
  ];

  final List<Map<String, dynamic>> _timelineData = [
    {
      "period": "Ancient",
      "year": "1143 CE",
      "title": "Foundation of Amber Fort",
      "description":
          "The fort was originally built by Raja Alan Singh Chanda of the Chanda dynasty of Meenas in 1143 CE. The location was chosen for its strategic position overlooking the Maota Lake.",
      "details":
          "The original structure was a small hilltop fort that served as a watchtower and defensive position. Archaeological evidence suggests that the site was inhabited even earlier by various Rajput clans."
    },
    {
      "period": "Medieval",
      "year": "1592 CE",
      "title": "Expansion by Man Singh I",
      "description":
          "Raja Man Singh I, one of the nine jewels (Navaratnas) of Akbar's court, significantly expanded and renovated the fort complex.",
      "details":
          "Man Singh I added the main palace complex, including the Diwan-i-Aam (Hall of Public Audience) and several residential quarters. The architectural style began to show Mughal influences during this period."
    },
    {
      "period": "Medieval",
      "year": "1727 CE",
      "title": "Final Architectural Phase",
      "description":
          "Sawai Jai Singh II completed the fort's construction, adding the magnificent Sheesh Mahal (Mirror Palace) and other ornate structures.",
      "details":
          "This period saw the addition of intricate mirror work, detailed frescoes, and the famous Ganesh Gate. The fort reached its current architectural grandeur during this time."
    },
    {
      "period": "Colonial",
      "year": "1876 CE",
      "title": "British Documentation",
      "description":
          "The British colonial administration documented the fort as part of their archaeological survey of India, recognizing its historical significance.",
      "details":
          "Detailed architectural drawings and historical records were created during this period, helping preserve knowledge about the fort's construction techniques and historical importance."
    },
    {
      "period": "Modern",
      "year": "2013 CE",
      "title": "UNESCO World Heritage Status",
      "description":
          "Amber Fort was inscribed as a UNESCO World Heritage Site as part of the Hill Forts of Rajasthan, recognizing its outstanding universal value.",
      "details":
          "The designation highlighted the fort's exceptional testimony to the Rajput military hill architecture and its role in the cultural landscape of Rajasthan."
    }
  ];

  final List<Map<String, dynamic>> _communityPhotos = [
    {
      "imageUrl":
          "https://images.unsplash.com/photo-1477587458883-47145ed94245?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "userName": "Priya Sharma",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "uploadDate": "2 days ago",
      "likes": 24,
      "caption": "Beautiful sunset view from the ramparts"
    },
    {
      "imageUrl":
          "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "userName": "Rajesh Kumar",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "uploadDate": "1 week ago",
      "likes": 18,
      "caption": "Intricate mirror work in Sheesh Mahal"
    },
    {
      "imageUrl":
          "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "userName": "Sarah Johnson",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "uploadDate": "2 weeks ago",
      "likes": 31,
      "caption": "Amazing architecture and craftsmanship"
    },
    {
      "imageUrl":
          "https://images.unsplash.com/photo-1545558014-8692077e9b5c?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "userName": "Amit Patel",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "uploadDate": "3 weeks ago",
      "likes": 15,
      "caption": "Elephant ride experience at the entrance"
    },
    {
      "imageUrl":
          "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "userName": "Lisa Chen",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "uploadDate": "1 month ago",
      "likes": 42,
      "caption": "Panoramic view of Jaipur city from the fort"
    },
    {
      "imageUrl":
          "https://images.unsplash.com/photo-1548013146-72479768bada?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "userName": "Mohammed Ali",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "uploadDate": "1 month ago",
      "likes": 28,
      "caption": "Traditional Rajasthani architecture at its finest"
    },
    {
      "imageUrl":
          "https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "userName": "Emma Wilson",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "uploadDate": "2 months ago",
      "likes": 35,
      "caption": "Detailed carvings and artistic elements"
    }
  ];

  final List<Map<String, dynamic>> _relatedMonuments = [
    {
      "name": "City Palace Jaipur",
      "location": "Jaipur, Rajasthan",
      "imageUrl":
          "https://images.unsplash.com/photo-1477587458883-47145ed94245?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "12 km",
      "rating": 4.6,
      "travelTime": "25 min"
    },
    {
      "name": "Hawa Mahal",
      "location": "Jaipur, Rajasthan",
      "imageUrl":
          "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "15 km",
      "rating": 4.4,
      "travelTime": "30 min"
    },
    {
      "name": "Jaigarh Fort",
      "location": "Jaipur, Rajasthan",
      "imageUrl":
          "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "3 km",
      "rating": 4.3,
      "travelTime": "8 min"
    },
    {
      "name": "Nahargarh Fort",
      "location": "Jaipur, Rajasthan",
      "imageUrl":
          "https://images.unsplash.com/photo-1545558014-8692077e9b5c?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "8 km",
      "rating": 4.2,
      "travelTime": "18 min"
    }
  ];

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    final showTitle = _scrollController.offset > 200;
    if (showTitle != _showAppBarTitle) {
      setState(() {
        _showAppBarTitle = showTitle;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: Stack(
        children: [
          // Main Content
          CustomScrollView(
            controller: _scrollController,
            slivers: [
              // App Bar
              SliverAppBar(
                expandedHeight: 35.h,
                floating: false,
                pinned: true,
                backgroundColor: colorScheme.surface,
                elevation: 0,
                systemOverlayStyle: SystemUiOverlayStyle(
                  statusBarColor: Colors.transparent,
                  statusBarIconBrightness: theme.brightness == Brightness.light
                      ? Brightness.dark
                      : Brightness.light,
                ),
                leading: Container(
                  margin: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(2.w),
                  ),
                  child: IconButton(
                    icon: CustomIconWidget(
                      iconName: 'arrow_back',
                      color: Colors.white,
                      size: 6.w,
                    ),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
                actions: [
                  Container(
                    margin: EdgeInsets.all(2.w),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                    child: IconButton(
                      icon: CustomIconWidget(
                        iconName: 'share',
                        color: Colors.white,
                        size: 6.w,
                      ),
                      onPressed: _shareMonument,
                    ),
                  ),
                ],
                title: _showAppBarTitle
                    ? Text(
                        'Amber Fort',
                        style: theme.textTheme.titleLarge?.copyWith(
                          color: colorScheme.onSurface,
                          fontWeight: FontWeight.w600,
                        ),
                      )
                    : null,
                flexibleSpace: FlexibleSpaceBar(
                  background: MonumentHeroCarousel(
                    images: _monumentImages,
                    monumentName: 'Amber Fort',
                  ),
                ),
              ),

              // Content
              SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Monument Header
                    MonumentHeader(
                      monumentName: 'Amber Fort (Amer Fort)',
                      location: 'Amer, Jaipur, Rajasthan 302001',
                      rating: 4.5,
                      reviewCount: 12847,
                      onAudioPronunciation: _playPronunciation,
                    ),

                    SizedBox(height: 2.h),

                    // Start Audio Guide Button
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _startAudioGuide,
                        icon: CustomIconWidget(
                          iconName: 'play_circle_filled',
                          color: colorScheme.onPrimary,
                          size: 6.w,
                        ),
                        label: Text(
                          'Start Audio Guide',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: colorScheme.onPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: colorScheme.primary,
                          padding: EdgeInsets.symmetric(vertical: 2.h),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(3.w),
                          ),
                          elevation: 3,
                        ),
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Content Sections
                    ContentSectionCard(
                      title: 'Historical Overview',
                      icon: Icons.history_edu,
                      initiallyExpanded: true,
                      content:
                          '''Amber Fort, also known as Amer Fort, is a magnificent hilltop fortress located in Amer, a town near Jaipur in Rajasthan, India. Built in 1592 by Raja Man Singh I, one of Emperor Akbar's most trusted generals, this UNESCO World Heritage Site represents the pinnacle of Rajput architecture and military engineering.

The fort served as the main residence of the Rajput Maharajas and their families for centuries. Its strategic location on a hilltop provided excellent defense capabilities while offering breathtaking views of the surrounding Aravalli Hills and Maota Lake below.

The name "Amber" is derived from Ambikeshwar, after the Hindu goddess Amba or Ambika, who was worshipped in the area. The fort complex covers an area of 4 square kilometers and is renowned for its artistic Hindu style elements, with large ramparts and series of gates and cobbled paths.''',
                    ),

                    ContentSectionCard(
                      title: 'Architecture Details',
                      icon: Icons.architecture,
                      content:
                          '''The Amber Fort showcases a perfect blend of Hindu and Mughal architectural styles, reflecting the cultural synthesis that characterized the Mughal period. The fort is constructed using red sandstone and marble, creating a stunning visual contrast that changes color with the light throughout the day.

Key architectural features include:

**Sheesh Mahal (Mirror Palace)**: The most famous attraction, featuring intricate mirror work with thousands of tiny mirrors embedded in the walls and ceiling. When lit by candles or flashlights, the entire hall sparkles like a starry night sky.

**Diwan-i-Aam (Hall of Public Audience)**: A large hall with rows of columns where the Maharaja would hold court and address public grievances. The hall features beautiful latticed galleries and carved pillars.

**Diwan-i-Khas (Hall of Private Audience)**: An elegant hall decorated with precious stones and mirrors, where the king would meet with important dignitaries and discuss state matters.

**Ganesh Gate**: The main entrance to the private palaces, adorned with beautiful frescoes and featuring a stunning image of Lord Ganesha above the doorway.''',
                    ),

                    ContentSectionCard(
                      title: 'Cultural Significance',
                      icon: Icons.temple_hindu,
                      content:
                          '''Amber Fort holds immense cultural and historical significance as a symbol of Rajput valor, architectural brilliance, and the rich heritage of Rajasthan. It represents the golden age of Rajput civilization and their sophisticated understanding of military architecture, urban planning, and artistic expression.

The fort has been a witness to numerous historical events, including royal ceremonies, political alliances, and cultural celebrations. It served as the seat of power for the Kachwaha Rajput dynasty for over 600 years, making it one of the most important political centers in medieval India.

Cultural elements include:

**Religious Significance**: The fort houses several temples, including the famous Shila Devi Temple, dedicated to the goddess Kali. The temple contains a silver door and marble carvings that showcase the religious devotion of the Rajput rulers.

**Artistic Heritage**: The fort is renowned for its exquisite frescoes, mirror work, and stone carvings that depict scenes from Hindu mythology, royal life, and natural motifs. These artworks represent the pinnacle of Rajasthani craftsmanship.

**Living Heritage**: The fort continues to be a center of cultural activities, hosting light and sound shows, cultural performances, and festivals that keep the Rajasthani traditions alive.''',
                    ),

                    ContentSectionCard(
                      title: 'Visitor Tips',
                      icon: Icons.tips_and_updates,
                      content:
                          '''To make the most of your visit to Amber Fort, here are some essential tips and recommendations:

**Best Time to Visit**: 
- October to March: Pleasant weather, ideal for exploration
- Early morning (8-10 AM) or late afternoon (4-6 PM): Avoid crowds and harsh sunlight
- Sunset visits offer spectacular views and photography opportunities

**What to Bring**:
- Comfortable walking shoes with good grip for cobblestone paths
- Sun protection: hat, sunglasses, and sunscreen
- Water bottle to stay hydrated
- Camera for capturing the stunning architecture and views

**Transportation**:
- Elephant rides: Traditional way to reach the fort (available in morning hours)
- Jeep rides: Faster alternative for those preferring not to walk uphill
- Walking: Free option, takes about 15-20 minutes uphill

**Photography Tips**:
- Sheesh Mahal looks best with mobile flashlight creating mirror reflections
- Golden hour lighting enhances the red sandstone architecture
- Panoramic views from ramparts are perfect for landscape photography

**Cultural Etiquette**:
- Dress modestly, especially when visiting temple areas
- Remove shoes before entering temple premises
- Be respectful during prayer times and ceremonies

**Duration**: Plan for 2-3 hours to explore the main areas thoroughly, or 4-5 hours for a comprehensive visit including all sections.''',
                    ),

                    SizedBox(height: 3.h),

                    // Interactive Timeline
                    InteractiveTimeline(timelineData: _timelineData),

                    SizedBox(height: 3.h),

                    // Photo Gallery
                    PhotoGallerySection(
                      communityPhotos: _communityPhotos,
                      onUploadPhoto: _uploadPhoto,
                    ),

                    SizedBox(height: 3.h),

                    // Related Monuments
                    RelatedMonumentsSection(
                        relatedMonuments: _relatedMonuments),

                    SizedBox(height: 10.h), // Space for bottom action bar
                  ],
                ),
              ),
            ],
          ),

          // Bottom Action Bar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: BottomActionBar(
              isFavorite: _isFavorite,
              onFavoriteToggle: _toggleFavorite,
              onShare: _shareMonument,
              onRate: _rateExperience,
              onUploadPhoto: _uploadPhoto,
              onGetDirections: _getDirections,
            ),
          ),
        ],
      ),
    );
  }

  void _playPronunciation() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Playing pronunciation: "Amber Fort"'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _startAudioGuide() {
    Navigator.pushNamed(context, '/voice-guide-player');
  }

  void _toggleFavorite() {
    setState(() {
      _isFavorite = !_isFavorite;
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content:
            Text(_isFavorite ? 'Added to favorites' : 'Removed from favorites'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _shareMonument() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Sharing Amber Fort details...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _rateExperience() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rate Your Experience'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('How was your visit to Amber Fort?'),
            SizedBox(height: 2.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content:
                            Text('Thank you for rating ${index + 1} stars!'),
                        duration: const Duration(seconds: 2),
                      ),
                    );
                  },
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 1.w),
                    child: CustomIconWidget(
                      iconName: 'star_border',
                      color: Colors.amber,
                      size: 8.w,
                    ),
                  ),
                );
              }),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _uploadPhoto() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(5.w)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Upload Photo',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 2.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'camera_alt',
                color: Theme.of(context).colorScheme.primary,
                size: 6.w,
              ),
              title: const Text('Take Photo'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Opening camera...'),
                    duration: Duration(seconds: 2),
                  ),
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'photo_library',
                color: Theme.of(context).colorScheme.primary,
                size: 6.w,
              ),
              title: const Text('Choose from Gallery'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Opening gallery...'),
                    duration: Duration(seconds: 2),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _getDirections() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening directions to Amber Fort...'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
