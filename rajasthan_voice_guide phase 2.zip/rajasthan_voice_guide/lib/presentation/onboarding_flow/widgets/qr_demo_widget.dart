import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QrDemoWidget extends StatefulWidget {
  const QrDemoWidget({super.key});

  @override
  State<QrDemoWidget> createState() => _QrDemoWidgetState();
}

class _QrDemoWidgetState extends State<QrDemoWidget>
    with SingleTickerProviderStateMixin {
  bool _isScanning = false;
  late AnimationController _animationController;
  late Animation<double> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _slideAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _startQrDemo() {
    HapticFeedback.lightImpact();
    setState(() {
      _isScanning = true;
    });

    _animationController.repeat();

    // Simulate QR code detection after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _isScanning = false;
        });
        _animationController.stop();
        _animationController.reset();

        // Show success feedback
        HapticFeedback.mediumImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Monument detected! Taj Mahal'),
            backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      children: [
        Text(
          'Tap to simulate QR scanning',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: colorScheme.onSurface.withValues(alpha: 0.7),
          ),
        ),
        SizedBox(height: 2.h),
        GestureDetector(
          onTap: _isScanning ? null : _startQrDemo,
          child: Container(
            width: 40.w,
            height: 25.w,
            decoration: BoxDecoration(
              color: colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _isScanning
                    ? colorScheme.tertiary
                    : colorScheme.outline.withValues(alpha: 0.3),
                width: 2,
              ),
            ),
            child: Stack(
              children: [
                // QR code placeholder
                Center(
                  child: Container(
                    width: 20.w,
                    height: 20.w,
                    decoration: BoxDecoration(
                      color: colorScheme.onSurface.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: CustomIconWidget(
                      iconName: 'qr_code',
                      color: colorScheme.onSurface.withValues(alpha: 0.5),
                      size: 40,
                    ),
                  ),
                ),

                // Scanning line animation
                if (_isScanning)
                  AnimatedBuilder(
                    animation: _slideAnimation,
                    builder: (context, child) {
                      return Positioned(
                        top: 25.w * _slideAnimation.value - 2,
                        left: 0,
                        right: 0,
                        child: Container(
                          height: 2,
                          decoration: BoxDecoration(
                            color: colorScheme.tertiary,
                            boxShadow: [
                              BoxShadow(
                                color:
                                    colorScheme.tertiary.withValues(alpha: 0.5),
                                blurRadius: 4,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),

                // Corner indicators
                ...List.generate(4, (index) {
                  final isTop = index < 2;
                  final isLeft = index % 2 == 0;

                  return Positioned(
                    top: isTop ? 8 : null,
                    bottom: !isTop ? 8 : null,
                    left: isLeft ? 8 : null,
                    right: !isLeft ? 8 : null,
                    child: Container(
                      width: 4.w,
                      height: 4.w,
                      decoration: BoxDecoration(
                        border: Border(
                          top: isTop
                              ? BorderSide(
                                  color: _isScanning
                                      ? colorScheme.tertiary
                                      : colorScheme.primary,
                                  width: 3,
                                )
                              : BorderSide.none,
                          bottom: !isTop
                              ? BorderSide(
                                  color: _isScanning
                                      ? colorScheme.tertiary
                                      : colorScheme.primary,
                                  width: 3,
                                )
                              : BorderSide.none,
                          left: isLeft
                              ? BorderSide(
                                  color: _isScanning
                                      ? colorScheme.tertiary
                                      : colorScheme.primary,
                                  width: 3,
                                )
                              : BorderSide.none,
                          right: !isLeft
                              ? BorderSide(
                                  color: _isScanning
                                      ? colorScheme.tertiary
                                      : colorScheme.primary,
                                  width: 3,
                                )
                              : BorderSide.none,
                        ),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        ),
        if (_isScanning) ...[
          SizedBox(height: 2.h),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: colorScheme.tertiary.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 4.w,
                  height: 4.w,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      colorScheme.tertiary,
                    ),
                  ),
                ),
                SizedBox(width: 2.w),
                Text(
                  'Scanning for monuments...',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.tertiary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
