import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/chat_message_widget.dart';
import './widgets/text_input_widget.dart';
import './widgets/typing_indicator_widget.dart';
import './widgets/voice_input_widget.dart';

class AiChatInterface extends StatefulWidget {
  const AiChatInterface({super.key});

  @override
  State<AiChatInterface> createState() => _AiChatInterfaceState();
}

class _AiChatInterfaceState extends State<AiChatInterface>
    with TickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  bool _isTyping = false;
  bool _showVoiceInput = false;
  late TabController _tabController;

  // Mock cultural data for AI responses
  final List<Map<String, dynamic>> _culturalData = [
    {
      "monument": "Amber Fort",
      "description":
          "Amber Fort, also known as Amer Fort, is a magnificent fort located in Amer, Rajasthan. Built in 1592 by Raja Man Singh I, it showcases a blend of Hindu and Mughal architecture with its red sandstone and marble construction.",
      "quickReplies": [
        "Show directions",
        "Tell me more",
        "Related places",
        "Audio guide"
      ],
      "audioUrl": "https://example.com/amber-fort-audio.mp3",
    },
    {
      "monument": "Hawa Mahal",
      "description":
          "The Hawa Mahal or 'Palace of Winds' is a stunning five-story palace built in 1799 by Maharaja Sawai Pratap Singh. Its unique honeycomb structure with 953 small windows allowed royal ladies to observe street festivals while remaining unseen.",
      "quickReplies": [
        "Architecture details",
        "Visit timings",
        "Nearby attractions",
        "Photo spots"
      ],
      "audioUrl": "https://example.com/hawa-mahal-audio.mp3",
    },
    {
      "monument": "City Palace",
      "description":
          "The City Palace complex in Jaipur is a magnificent blend of Rajasthani and Mughal architecture. Built by Maharaja Sawai Jai Singh II, it houses museums displaying royal artifacts, textiles, and weapons from Rajasthan's rich history.",
      "quickReplies": [
        "Museum timings",
        "Ticket prices",
        "Royal artifacts",
        "Photography rules"
      ],
      "audioUrl": "https://example.com/city-palace-audio.mp3",
    },
    {
      "festival": "Pushkar Camel Fair",
      "description":
          "The Pushkar Camel Fair is one of the world's largest camel fairs held annually in Pushkar, Rajasthan. This vibrant festival features camel trading, folk performances, traditional competitions, and spiritual activities around the sacred Pushkar Lake.",
      "quickReplies": [
        "Fair dates",
        "Accommodation",
        "Activities",
        "How to reach"
      ],
      "audioUrl": "https://example.com/pushkar-fair-audio.mp3",
    },
    {
      "culture": "Rajasthani Folk Dance",
      "description":
          "Rajasthani folk dances like Ghoomar, Kalbeliya, and Bhavai are integral to the state's cultural heritage. These dances tell stories of valor, love, and daily life, performed in colorful traditional costumes with rhythmic music.",
      "quickReplies": [
        "Dance forms",
        "Cultural shows",
        "Learn dance",
        "Traditional music"
      ],
      "audioUrl": "https://example.com/folk-dance-audio.mp3",
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _addWelcomeMessage();
  }

  void _addWelcomeMessage() {
    setState(() {
      _messages.add({
        "message":
            "Namaste! I'm your AI heritage guide for Rajasthan. Ask me about monuments, culture, festivals, or anything about the Land of Kings. How can I help you explore today?",
        "type": MessageType.ai,
        "timestamp": DateTime.now(),
        "quickReplies": [
          "Popular monuments",
          "Cultural festivals",
          "Local cuisine",
          "Travel tips"
        ],
      });
    });
  }

  void _sendMessage(String message) {
    if (message.trim().isEmpty) return;

    setState(() {
      _messages.add({
        "message": message,
        "type": MessageType.user,
        "timestamp": DateTime.now(),
      });
      _isTyping = true;
    });

    _scrollToBottom();
    _generateAIResponse(message);
  }

  void _generateAIResponse(String userMessage) {
    // Simulate AI processing delay
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;

      final response = _getContextualResponse(userMessage);

      setState(() {
        _isTyping = false;
        _messages.add({
          "message": response["message"],
          "type": MessageType.ai,
          "timestamp": DateTime.now(),
          "quickReplies": response["quickReplies"],
          "audioUrl": response["audioUrl"],
        });
      });

      _scrollToBottom();
    });
  }

  Map<String, dynamic> _getContextualResponse(String userMessage) {
    final lowerMessage = userMessage.toLowerCase();

    // Check for specific monument queries
    for (final data in _culturalData) {
      if (data.containsKey("monument")) {
        final monumentName = (data["monument"] as String).toLowerCase();
        if (lowerMessage.contains(monumentName.split(' ')[0])) {
          return {
            "message": data["description"],
            "quickReplies": data["quickReplies"],
            "audioUrl": data["audioUrl"],
          };
        }
      }
    }

    // Check for festival queries
    if (lowerMessage.contains("festival") ||
        lowerMessage.contains("fair") ||
        lowerMessage.contains("pushkar")) {
      final festivalData =
          _culturalData.firstWhere((data) => data.containsKey("festival"));
      return {
        "message": festivalData["description"],
        "quickReplies": festivalData["quickReplies"],
        "audioUrl": festivalData["audioUrl"],
      };
    }

    // Check for culture/dance queries
    if (lowerMessage.contains("dance") ||
        lowerMessage.contains("culture") ||
        lowerMessage.contains("ghoomar")) {
      final cultureData =
          _culturalData.firstWhere((data) => data.containsKey("culture"));
      return {
        "message": cultureData["description"],
        "quickReplies": cultureData["quickReplies"],
        "audioUrl": cultureData["audioUrl"],
      };
    }

    // Default responses for common queries
    if (lowerMessage.contains("popular") || lowerMessage.contains("monument")) {
      return {
        "message":
            "Rajasthan's most popular monuments include:\n\n🏰 Amber Fort - Majestic hilltop fortress\n🏛️ Hawa Mahal - Palace of Winds\n🏰 City Palace - Royal residence complex\n🕌 Jantar Mantar - Astronomical observatory\n🏰 Mehrangarh Fort - Blue city's crown\n\nWhich one would you like to explore first?",
        "quickReplies": [
          "Amber Fort",
          "Hawa Mahal",
          "City Palace",
          "Mehrangarh Fort"
        ],
        "audioUrl": null,
      };
    }

    if (lowerMessage.contains("food") || lowerMessage.contains("cuisine")) {
      return {
        "message":
            "Rajasthani cuisine is a royal feast! Must-try dishes include:\n\n🍛 Dal Baati Churma - Traditional lentil curry with baked bread\n🥘 Laal Maas - Spicy red meat curry\n🍰 Ghevar - Sweet honeycomb dessert\n🥟 Kachori - Spiced fried bread\n🍵 Masala Chai - Spiced tea\n\nEach dish tells a story of desert survival and royal indulgence!",
        "quickReplies": [
          "Best restaurants",
          "Cooking classes",
          "Street food",
          "Vegetarian options"
        ],
        "audioUrl": null,
      };
    }

    if (lowerMessage.contains("travel") || lowerMessage.contains("tip")) {
      return {
        "message":
            "Here are essential travel tips for Rajasthan:\n\n🌡️ Best time: October to March (pleasant weather)\n👕 Dress: Light cotton clothes, comfortable shoes\n💧 Stay hydrated: Carry water bottles\n📱 Apps: Download offline maps and guides\n🚗 Transport: Pre-book cabs for long distances\n💰 Budget: ₹2000-5000 per day depending on comfort level",
        "quickReplies": [
          "Weather info",
          "Transportation",
          "Accommodation",
          "Budget planning"
        ],
        "audioUrl": null,
      };
    }

    // Generic helpful response
    return {
      "message":
          "I'd love to help you discover Rajasthan's treasures! You can ask me about:\n\n🏰 Historic monuments and forts\n🎭 Cultural festivals and traditions\n🍛 Local cuisine and specialties\n🎨 Arts, crafts, and shopping\n🗺️ Travel routes and planning\n📸 Photography spots\n\nWhat interests you most?",
      "quickReplies": ["Monuments", "Festivals", "Food", "Shopping"],
      "audioUrl": null,
    };
  }

  void _handleQuickReply(String reply) {
    _sendMessage(reply);
  }

  void _playAudio(String? audioUrl) {
    if (audioUrl != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Playing audio guide...'),
          backgroundColor: AppTheme.lightTheme.colorScheme.primary,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _clearChat() {
    setState(() {
      _messages.clear();
    });
    _addWelcomeMessage();
  }

  void _shareChat() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Chat history shared successfully!'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(2.w),
              ),
              child: CustomIconWidget(
                iconName: 'psychology',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'AI Heritage Guide',
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    'Your cultural companion',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onPrimary
                          .withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
        elevation: 2,
        actions: [
          IconButton(
            icon: CustomIconWidget(
              iconName: 'share',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 6.w,
            ),
            onPressed: _shareChat,
          ),
          PopupMenuButton<String>(
            icon: CustomIconWidget(
              iconName: 'more_vert',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 6.w,
            ),
            onSelected: (value) {
              switch (value) {
                case 'clear':
                  _clearChat();
                  break;
                case 'voice_guide':
                  Navigator.pushNamed(context, '/voice-guide-player');
                  break;
                case 'explore':
                  Navigator.pushNamed(context, '/explore-screen');
                  break;
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'clear',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'clear_all',
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      size: 5.w,
                    ),
                    SizedBox(width: 3.w),
                    Text('Clear Chat'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'voice_guide',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'record_voice_over',
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      size: 5.w,
                    ),
                    SizedBox(width: 3.w),
                    Text('Voice Guide'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'explore',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'explore',
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      size: 5.w,
                    ),
                    SizedBox(width: 3.w),
                    Text('Explore Places'),
                  ],
                ),
              ),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              icon: CustomIconWidget(
                iconName: 'chat',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 5.w,
              ),
              text: 'Chat',
            ),
            Tab(
              icon: CustomIconWidget(
                iconName: 'mic',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 5.w,
              ),
              text: 'Voice',
            ),
          ],
          labelColor: AppTheme.lightTheme.colorScheme.onPrimary,
          unselectedLabelColor:
              AppTheme.lightTheme.colorScheme.onPrimary.withValues(alpha: 0.7),
          indicatorColor: AppTheme.lightTheme.colorScheme.onPrimary,
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.05),
              AppTheme.lightTheme.scaffoldBackgroundColor,
            ],
          ),
        ),
        child: TabBarView(
          controller: _tabController,
          children: [
            // Chat Tab
            Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    controller: _scrollController,
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    itemCount: _messages.length + (_isTyping ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index == _messages.length && _isTyping) {
                        return const TypingIndicatorWidget();
                      }

                      final message = _messages[index];
                      return ChatMessageWidget(
                        message: message["message"],
                        type: message["type"],
                        timestamp: message["timestamp"],
                        audioUrl: message["audioUrl"],
                        quickReplies: message["quickReplies"] != null
                            ? List<String>.from(message["quickReplies"])
                            : null,
                        onPlayAudio: () => _playAudio(message["audioUrl"]),
                        onQuickReply: _handleQuickReply,
                      );
                    },
                  ),
                ),
                TextInputWidget(
                  onSendMessage: _sendMessage,
                  isEnabled: !_isTyping,
                ),
              ],
            ),
            // Voice Tab
            Column(
              children: [
                Expanded(
                  child: _messages.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomIconWidget(
                                iconName: 'mic',
                                color: AppTheme.lightTheme.colorScheme.primary
                                    .withValues(alpha: 0.5),
                                size: 20.w,
                              ),
                              SizedBox(height: 4.h),
                              Text(
                                'Voice Chat Ready',
                                style: theme.textTheme.headlineSmall?.copyWith(
                                  color:
                                      AppTheme.lightTheme.colorScheme.primary,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              SizedBox(height: 2.h),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 8.w),
                                child: Text(
                                  'Tap the microphone below to start asking about Rajasthan\'s heritage, culture, and monuments',
                                  textAlign: TextAlign.center,
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: AppTheme
                                        .lightTheme.colorScheme.onSurface
                                        .withValues(alpha: 0.7),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: _scrollController,
                          padding: EdgeInsets.symmetric(vertical: 2.h),
                          itemCount: _messages.length + (_isTyping ? 1 : 0),
                          itemBuilder: (context, index) {
                            if (index == _messages.length && _isTyping) {
                              return const TypingIndicatorWidget();
                            }

                            final message = _messages[index];
                            return ChatMessageWidget(
                              message: message["message"],
                              type: message["type"],
                              timestamp: message["timestamp"],
                              audioUrl: message["audioUrl"],
                              quickReplies: message["quickReplies"] != null
                                  ? List<String>.from(message["quickReplies"])
                                  : null,
                              onPlayAudio: () =>
                                  _playAudio(message["audioUrl"]),
                              onQuickReply: _handleQuickReply,
                            );
                          },
                        ),
                ),
                VoiceInputWidget(
                  onVoiceMessage: _sendMessage,
                  onRecordingStart: () {
                    setState(() {
                      _showVoiceInput = true;
                    });
                  },
                  onRecordingStop: () {
                    setState(() {
                      _showVoiceInput = false;
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: _tabController.index == 0
          ? FloatingActionButton(
              onPressed: () {
                _tabController.animateTo(1);
              },
              backgroundColor: AppTheme.lightTheme.colorScheme.primary,
              child: CustomIconWidget(
                iconName: 'mic',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 6.w,
              ),
            )
          : null,
    );
  }
}
