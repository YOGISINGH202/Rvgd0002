import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/filter_chips_widget.dart';
import './widgets/map_toggle_widget.dart';
import './widgets/map_view_widget.dart';
import './widgets/monument_card_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/sort_options_widget.dart';
import './widgets/trending_section_widget.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  String _searchQuery = '';
  String _selectedCategory = 'All';
  String _selectedSort = 'distance';
  bool _isMapView = false;

  // Mock data for monuments
  final List<Map<String, dynamic>> _allMonuments = [
    {
      "id": 1,
      "name": "Hawa Mahal",
      "description":
          "The Palace of Winds, an iconic pink sandstone structure with intricate lattice work and 953 small windows.",
      "category": "Palaces",
      "image":
          "https://images.unsplash.com/photo-1599661046827-dacde6976549?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "2.3 km",
      "rating": 4.6,
      "latitude": 26.9239,
      "longitude": 75.8267,
    },
    {
      "id": 2,
      "name": "Amber Fort",
      "description":
          "A majestic fort complex built with red sandstone and marble, showcasing Rajput architecture at its finest.",
      "category": "Forts",
      "image":
          "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "11.2 km",
      "rating": 4.8,
      "latitude": 26.9855,
      "longitude": 75.8513,
    },
    {
      "id": 3,
      "name": "City Palace",
      "description":
          "A magnificent palace complex that blends Rajasthani and Mughal architecture, housing museums and courtyards.",
      "category": "Palaces",
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "1.8 km",
      "rating": 4.7,
      "latitude": 26.9255,
      "longitude": 75.8235,
    },
    {
      "id": 4,
      "name": "Jantar Mantar",
      "description":
          "An astronomical observatory featuring the world's largest stone sundial and various astronomical instruments.",
      "category": "Museums",
      "image":
          "https://images.unsplash.com/photo-1582719471137-c3967ffb1c42?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "2.1 km",
      "rating": 4.4,
      "latitude": 26.9246,
      "longitude": 75.8249,
    },
    {
      "id": 5,
      "name": "Jal Mahal",
      "description":
          "The Water Palace, a stunning architectural marvel situated in the middle of Man Sagar Lake.",
      "category": "Palaces",
      "image":
          "https://images.unsplash.com/photo-1609920658906-8223bd289001?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "6.5 km",
      "rating": 4.5,
      "latitude": 26.9530,
      "longitude": 75.8460,
    },
    {
      "id": 6,
      "name": "Nahargarh Fort",
      "description":
          "A hilltop fort offering panoramic views of Jaipur city, built as a retreat for the royal family.",
      "category": "Forts",
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "8.7 km",
      "rating": 4.3,
      "latitude": 26.9344,
      "longitude": 75.8155,
    },
    {
      "id": 7,
      "name": "Birla Mandir",
      "description":
          "A beautiful white marble temple dedicated to Lord Vishnu and Goddess Lakshmi, showcasing modern architecture.",
      "category": "Temples",
      "image":
          "https://images.unsplash.com/photo-1582719471137-c3967ffb1c42?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "4.2 km",
      "rating": 4.2,
      "latitude": 26.8851,
      "longitude": 75.8144,
    },
    {
      "id": 8,
      "name": "Johari Bazaar",
      "description":
          "The famous jewelry market of Jaipur, known for traditional Rajasthani gems, jewelry, and handicrafts.",
      "category": "Markets",
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "distance": "1.5 km",
      "rating": 4.1,
      "latitude": 26.9197,
      "longitude": 75.8242,
    },
  ];

  // Mock data for trending places
  final List<Map<String, dynamic>> _trendingPlaces = [
    {
      "id": 1,
      "name": "Hawa Mahal",
      "location": "Old City, Jaipur",
      "category": "Palace",
      "image":
          "https://images.unsplash.com/photo-1599661046827-dacde6976549?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.6,
      "visitors": "2.5K",
    },
    {
      "id": 2,
      "name": "Amber Fort",
      "location": "Amer, Jaipur",
      "category": "Fort",
      "image":
          "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.8,
      "visitors": "3.2K",
    },
    {
      "id": 3,
      "name": "City Palace",
      "location": "City Palace Rd, Jaipur",
      "category": "Palace",
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.7,
      "visitors": "1.8K",
    },
  ];

  final List<String> _categories = [
    'All',
    'Forts',
    'Palaces',
    'Temples',
    'Museums',
    'Markets',
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(
        title: Text(
          'Explore Rajasthan',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
            color: colorScheme.onPrimary,
          ),
        ),
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        elevation: 2,
        actions: [
          MapToggleWidget(
            isMapView: _isMapView,
            onToggle: () {
              setState(() {
                _isMapView = !_isMapView;
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          SearchBarWidget(
            onSearchChanged: (query) {
              setState(() {
                _searchQuery = query;
              });
            },
            onVoiceSearch: _handleVoiceSearch,
            onFilterTap: _showAdvancedFilters,
          ),

          if (!_isMapView) ...[
            // Filter Chips
            FilterChipsWidget(
              categories: _categories,
              selectedCategory: _selectedCategory,
              onCategorySelected: (category) {
                setState(() {
                  _selectedCategory = category;
                });
              },
            ),

            // Sort Options
            SortOptionsWidget(
              selectedSort: _selectedSort,
              onSortChanged: (sort) {
                setState(() {
                  _selectedSort = sort;
                });
              },
            ),

            // Trending Section
            if (_searchQuery.isEmpty && _selectedCategory == 'All')
              TrendingSectionWidget(
                trendingPlaces: _trendingPlaces,
                onPlaceTap: _navigateToMonumentDetail,
              ),
          ],

          // Main Content
          Expanded(
            child: _isMapView
                ? MapViewWidget(
                    monuments: _getFilteredMonuments(),
                    onMonumentTap: _navigateToMonumentDetail,
                  )
                : _buildMonumentsList(),
          ),
        ],
      ),
    );
  }

  Widget _buildMonumentsList() {
    final filteredMonuments = _getFilteredMonuments();

    if (filteredMonuments.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      padding: EdgeInsets.only(bottom: 2.h),
      itemCount: filteredMonuments.length,
      itemBuilder: (context, index) {
        final monument = filteredMonuments[index];
        return MonumentCardWidget(
          monument: monument,
          onTap: () => _navigateToMonumentDetail(monument),
          onAudioPreview: () => _handleAudioPreview(monument),
          onFavorite: () => _handleFavorite(monument),
          onShare: () => _handleShare(monument),
          onDirections: () => _handleDirections(monument),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'search_off',
              color: colorScheme.onSurface.withValues(alpha: 0.4),
              size: 15.w,
            ),
            SizedBox(height: 3.h),
            Text(
              'No monuments found',
              style: theme.textTheme.titleMedium?.copyWith(
                color: colorScheme.onSurface.withValues(alpha: 0.7),
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'Try adjusting your search or filters to find what you\'re looking for.',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurface.withValues(alpha: 0.5),
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 3.h),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _searchQuery = '';
                  _selectedCategory = 'All';
                });
              },
              child: Text('Clear Filters'),
            ),
          ],
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _getFilteredMonuments() {
    List<Map<String, dynamic>> filtered = List.from(_allMonuments);

    // Filter by search query
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((monument) {
        final name = (monument["name"] as String).toLowerCase();
        final description = (monument["description"] as String).toLowerCase();
        final category = (monument["category"] as String).toLowerCase();
        final query = _searchQuery.toLowerCase();

        return name.contains(query) ||
            description.contains(query) ||
            category.contains(query);
      }).toList();
    }

    // Filter by category
    if (_selectedCategory != 'All') {
      filtered = filtered.where((monument) {
        return monument["category"] == _selectedCategory;
      }).toList();
    }

    // Sort monuments
    switch (_selectedSort) {
      case 'distance':
        filtered.sort((a, b) {
          final distanceA =
              double.parse((a["distance"] as String).replaceAll(' km', ''));
          final distanceB =
              double.parse((b["distance"] as String).replaceAll(' km', ''));
          return distanceA.compareTo(distanceB);
        });
        break;
      case 'popularity':
        // Sort by rating as a proxy for popularity
        filtered.sort(
            (a, b) => (b["rating"] as double).compareTo(a["rating"] as double));
        break;
      case 'rating':
        filtered.sort(
            (a, b) => (b["rating"] as double).compareTo(a["rating"] as double));
        break;
      case 'historical':
        // For demo, we'll sort alphabetically
        filtered.sort(
            (a, b) => (a["name"] as String).compareTo(b["name"] as String));
        break;
    }

    return filtered;
  }

  void _handleVoiceSearch() {
    // In a real app, this would implement voice recognition
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Voice search feature coming soon!'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _showAdvancedFilters() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: 60.h,
        decoration: BoxDecoration(
          color: colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              margin: EdgeInsets.only(top: 1.h),
              width: 10.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: colorScheme.onSurface.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            // Header
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Row(
                children: [
                  Text(
                    'Advanced Filters',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: colorScheme.onSurface,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        color: colorScheme.onSurface.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: CustomIconWidget(
                        iconName: 'close',
                        color: colorScheme.onSurface.withValues(alpha: 0.7),
                        size: 5.w,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Filter content
            Expanded(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Coming Soon',
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: colorScheme.onSurface,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      'Advanced filtering options including time period, architecture style, accessibility features, and entry fee range will be available soon.',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToMonumentDetail(Map<String, dynamic> monument) {
    Navigator.pushNamed(context, '/monument-detail-screen');
  }

  void _handleAudioPreview(Map<String, dynamic> monument) {
    Navigator.pushNamed(context, '/voice-guide-player');
  }

  void _handleFavorite(Map<String, dynamic> monument) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${monument["name"]} added to favorites!'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleShare(Map<String, dynamic> monument) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Sharing ${monument["name"]}...'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleDirections(Map<String, dynamic> monument) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening directions to ${monument["name"]}...'),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}
